# Assignment 2: Stack Overflow *(65 pts)*

**Deadline: 9/29**

In assignment 1 you learned to analyze tinybrowse with `grep`, `gdb`, and `strace`. 
In this assignment, you exploit tinybrowse using a cleverly crafted `.thtml` file.
Specifically, you will craft an end-to-end exploit for a stack buffer overflow in
tinybrowse's thtml attribute parsing.

You will write working shellcode, find the exact offset that lets you control a function's return address, locate a gadget that lets your exploit work without ever needing to know an absolute stack address, and combine all three into a `.thtml` file that, when tinybrowse opens it, spawns a shell.

**You turn in three things:** your shellcode (`shellcode.bin`), the offset you find
(`offset.txt`), and your finished exploit (`exploit.thtml`). 

## Part 0: Getting Started

Build tinybrowse the same way as assignment 1, from the `tinybrowse/` directory:

```sh
cd tinybrowse
make build
```

The following helper scripts are included in this assignment:
- `shellcode_harness.c` -- This harness will run your raw shellcode bytes in isolation, making it easier to debug. 
- `cyclic.py` -- This script generates/searches patterns to find your offset
- `build_exploit.py` -- assembles your offset, gadget address, and shellcode into a malicious `.thtml`

### The vulnerability

Take a look at `stage_attribute_value` and `read_string` in `src/tinyhtml/lexer.cpp`:

```cpp
void stage_attribute_value(const char* data, size_t len) {
    char raw[64];
    std::memcpy(raw, data, len);
}
```

```cpp
std::string read_string() {
    advance();  // consume opening '"'
    size_t start = pos;
    while (!at_end() && peek() != '"') {
        advance();
    }
    size_t len = pos - start;
    std::string result = decode_entities(source.substr(start, len));
    if (!at_end()) {
        advance();  // consume closing '"'
    }
    stage_attribute_value(source.data() + start, len);
    return result;
}
```

`read_string()` runs on every quoted attribute value in a `.thtml` document: `href`, `class`, `alt`, etc. It correctly computes `len`, the exact number of bytes between the
quotes, and hands it straight to `stage_attribute_value`, which copies exactly that many
bytes into a fixed 64-byte stack buffer.

The problem? `stage_attribute_value` never checks that `len <= 64`, and so a sufficiently
long attribute value will overflow the destination buffer.

## Part 1: Understand the vulnerability 

Before you start tring to exploit tinybrowse, make sure you can answer these for yourself.

- Trace how a byte you write in a `.thtml` file's `<a href="...">` attribute ends up as
  part of the `data`/`len` arguments to `stage_attribute_value`. What functions does it pass through?
- `raw` is a 64-byte stack array. When `len` is larger than 64, where -- physically, on the
  stack -- do the extra bytes end up? What's stored in that region under normal
  (non-attack) circumstances?

## Part 2: Write your shellcode

In order to spawn a shell, you need shellcode, i.e., a snippet of x86-64 machine code that calls `execve("/bin/sh", argv, NULL)` using only
registers and raw syscalls. If you don't know where to start, try this workflow:

- **Set up the syscall.** Put the right values in the syscall registers for `execve` and
  confirm each one immediately before your `syscall` instruction. 
- **Build the string.** Get `"/bin/sh"` on the stack, then take its addresses from `rsp`. 
- **Assemble it** 
  ```sh
  nasm -f bin -o shellcode.bin shellcode.s
  ```
- **Test it in isolation.** Rather than debugging your shellcode for the first time inside the full overflow, prove it works in isolation in the harness we provide you:
  ```sh
  clang-14 -o shellcode_harness ../pa/shellcode_harness.c
  ./shellcode_harness shellcode.bin
  ```
   This should pop a shell.


> **What to submit: `shellcode.bin`** *(25 pts)* -- your assembled shellcode.
> We run it in the harness against a fresh build; full credit if it opens a working shell.

## Part 3: Find your offset
To run your shellcode on the real overflow,
you need the exact number of bytes from the start of your attribute value to the saved
return address. Find it with `cyclic.py`.


> **What to submit: `offset.txt`** *(5 pts)* -- a single line containing the offset you found
> (the number `cyclic.py find` reported), as a plain decimal or `0x`-prefixed hex integer.

## Part 4: Find your gadget 

Overwriting the return address with the absolute stack address of your shellcode would mean
*knowing* that address -- but ASLR randomizes the stack's base on every run, so you don't.
The way around it is a gadget that jumps to wherever the stack pointer already points (`jmp *%rsp`). 


## Part 5: Combine and submit

Assemble your offset, gadget address, and shellcode into the final page using the provided `build_exploit.py` script.

Then run tinybrowse on it and confirm you get an interactive shell:

```sh
./build/src/browser/tinybrowse exploit.thtml
```

> **What to submit: `exploit.thtml`** *(35 pts)* -- your finished exploit. We run it against a fresh build of tinybrowse; full credit if it reproduces a working, interactive shell.

## Submission

Submit **`shellcode.bin`**, **`offset.txt`**, and **`exploit.thtml`** to Gradescope. There is
no long-form answer file for this assignment -- your grade only depends on whether your artifacts work.




