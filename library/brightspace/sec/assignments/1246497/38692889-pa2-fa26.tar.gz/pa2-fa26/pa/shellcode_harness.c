// Standalone shellcode test harness. Loads raw machine code from a file
// into an executable page and jumps to it. 
// Use this to debug your shellcode by itself before combining 
// it with the overflow.
//
// Usage:
//     clang-14 -o shellcode_harness shellcode_harness.c
//     nasm -f bin -o shellcode.bin shellcode.s
//     ./shellcode_harness shellcode.bin
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s shellcode.bin\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) {
        perror("fopen");
        return 1;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);

    void *mem = mmap(NULL, size, PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) {
        perror("mmap");
        fclose(f);
        return 1;
    }

    if (fread(mem, 1, size, f) != (size_t)size) {
        perror("fread");
        fclose(f);
        return 1;
    }
    fclose(f);

    void (*shellcode)(void) = (void (*)(void))mem;
    shellcode();

    return 0;
}
