#!/usr/bin/env python3
"""Cyclic pattern generator/finder for locating buffer-overflow offsets.

This script provides a repeating-but-locally-unique byte pattern which lets
you find, from a single crash, exactly how many padding bytes precede the
value you control.

Usage:
    python3 cyclic.py create LENGTH     # print a LENGTH-byte pattern
    python3 cyclic.py find VALUE        # find the offset of an 8-byte
                                        # little-endian hex VALUE

Typical workflow:
    1. python3 cyclic.py create 300 > pattern.bin, embed it as an
       attribute value in a crafted .thtml file, and run tinybrowse on it
       under gdb.
    2. Let it crash. Read the corrupted 8 bytes you control and 
        put that value to `find`.
    3. That offset tells you how many bytes of padding you need before
       your own 8-byte return-address overwrite.
"""
import argparse
import itertools
import string
import sys

ALPHA = string.ascii_uppercase
LOWER = string.ascii_lowercase
DIGITS = string.digits
MAX_LENGTH = len(ALPHA) * len(LOWER) * len(DIGITS) * 3


def cyclic(length):
    if length > MAX_LENGTH:
        raise ValueError(f"length {length} exceeds max pattern length {MAX_LENGTH}")
    out = bytearray()
    for a, b, c in itertools.product(ALPHA, LOWER, DIGITS):
        out += f"{a}{b}{c}".encode()
        if len(out) >= length:
            return bytes(out[:length])
    raise ValueError("pattern exhausted")  # unreachable given the length check above


def cyclic_find(value):
    pattern = cyclic(MAX_LENGTH)
    idx = pattern.find(value)
    if idx == -1:
        raise ValueError(f"{value!r} not found in the cyclic pattern")
    return idx


def main():
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_create = sub.add_parser("create", help="print a cyclic pattern of the given length")
    p_create.add_argument("length", type=int)

    p_find = sub.add_parser("find", help="find the offset of an 8-byte little-endian hex value")
    p_find.add_argument("value", help="hex value, e.g. 0x6461336461326461")

    args = parser.parse_args()

    if args.cmd == "create":
        sys.stdout.buffer.write(cyclic(args.length))
    elif args.cmd == "find":
        raw = int(args.value, 16).to_bytes(8, "little")
        print(cyclic_find(raw))


if __name__ == "__main__":
    main()
