#include "tinytest.h"

#include "tinyscript/interpreter.h"
#include "tinyscript/parser.h"

using namespace tinyscript;

namespace {

struct RunResult {
    Interpreter interp;
    std::vector<Diagnostic> diags;
    Program program;  // kept alive: interp.functions points into it
};

RunResult run(const std::string& source) {
    RunResult r;
    ParseResult parsed = parse(source);
    r.diags = parsed.diagnostics;
    r.program = std::move(parsed.program);
    collect_functions(r.interp, r.program);
    execute_program(r.interp, r.program, &r.diags);
    return r;
}

void cleanup(RunResult& r) {
    free_scope(r.interp.globals);
    free_program(r.program);
}

Value* global(RunResult& r, const std::string& name) {
    auto it = r.interp.globals.find(name);
    return it != r.interp.globals.end() ? &it->second : nullptr;
}

}  // namespace

TEST_CASE(arithmetic_wraps_and_promotes_like_the_spec_table) {
    RunResult r = run(
        "let a = 250u8 + 10u8;"       // wraps: 4
        "let b = -1i32 + 5u32;");     // promotes to u32, wraps: 4
    CHECK(r.diags.empty());
    CHECK_EQ(global(r, "a")->u8_val, static_cast<uint8_t>(4));
    CHECK_EQ(global(r, "b")->u32_val, static_cast<uint32_t>(4));
    cleanup(r);
}

TEST_CASE(string_concatenation_coerces_the_other_operand) {
    RunResult r = run("let s = \"count: \" + 42;");
    CHECK(r.diags.empty());
    CHECK_EQ(global(r, "s")->string_val, std::string("count: 42"));
    cleanup(r);
}

TEST_CASE(division_by_zero_is_a_diagnostic_and_execution_continues) {
    RunResult r = run("let a = 10 / 0; let b = 1;");
    CHECK_EQ(r.diags.size(), static_cast<size_t>(1));
    CHECK_EQ(global(r, "a")->i32_val, 0);
    CHECK_EQ(global(r, "b")->i32_val, 1);  // execution kept going after the error
    cleanup(r);
}

TEST_CASE(if_else_and_while_control_flow) {
    RunResult r = run(
        "let x = 0;"
        "if (1 < 2) { x = 1; } else { x = 2; }"
        "let i = 5;"
        "while (i > 0) { i = i - 1; }");
    CHECK(r.diags.empty());
    CHECK_EQ(global(r, "x")->i32_val, 1);
    CHECK_EQ(global(r, "i")->i32_val, 0);
    cleanup(r);
}

TEST_CASE(functions_take_params_and_return_values) {
    RunResult r = run("fn add(a, b) { return a + b; } let x = add(2, 3);");
    CHECK(r.diags.empty());
    CHECK_EQ(global(r, "x")->i32_val, 5);
    cleanup(r);
}

TEST_CASE(functions_do_not_see_the_caller_locals_no_closures) {
    RunResult r = run(
        "fn f() { return y; }"  // y is not a param, not a global -- undefined
        "let y = 99;"
        "let x = f();");
    // f() is called AFTER y is declared globally, so f() *can* see it (y is
    // global, not a caller-local) -- this confirms functions see globals...
    CHECK(r.diags.empty());
    CHECK_EQ(global(r, "x")->i32_val, 99);
    cleanup(r);

    // ...but NOT a caller's block-local variable of the same name.
    RunResult r2 = run(
        "fn f() { return z; }"
        "{ let z = 5; let x = f(); }");
    CHECK(!r2.diags.empty());  // "undefined variable 'z'" inside f()
    cleanup(r2);
}

TEST_CASE(function_hoisting_forward_reference_within_one_program) {
    RunResult r = run("let x = later(); fn later() { return 7; }");
    CHECK(r.diags.empty());
    CHECK_EQ(global(r, "x")->i32_val, 7);
    cleanup(r);
}

TEST_CASE(function_hoisting_across_two_blocks_sharing_one_interpreter) {
    ParseResult block1 = parse("let x = later();");
    ParseResult block2 = parse("fn later() { return 42; }");
    CHECK(block1.diagnostics.empty());
    CHECK(block2.diagnostics.empty());

    Interpreter interp;
    collect_functions(interp, block1.program);
    collect_functions(interp, block2.program);  // must happen before either executes

    std::vector<Diagnostic> diags;
    execute_program(interp, block1.program, &diags);
    execute_program(interp, block2.program, &diags);

    CHECK(diags.empty());
    auto it = interp.globals.find("x");
    CHECK(it != interp.globals.end());
    CHECK_EQ(it->second.i32_val, 42);

    free_scope(interp.globals);
    free_program(block1.program);
    free_program(block2.program);
}

TEST_CASE(array_literal_subscript_read_and_write) {
    RunResult r = run(
        "let arr = [1, 2, 3];"
        "let first = arr[0];"
        "arr[1] = 99;"
        "let second = arr[1];");
    CHECK(r.diags.empty());
    CHECK_EQ(global(r, "first")->i32_val, 1);
    CHECK_EQ(global(r, "second")->i32_val, 99);
    cleanup(r);
}

TEST_CASE(out_of_range_array_access_is_a_diagnostic_not_a_crash) {
    RunResult r = run("let arr = [1, 2, 3]; let x = arr[10]; arr[10] = 5;");
    CHECK_EQ(r.diags.size(), static_cast<size_t>(2));
    CHECK(global(r, "x")->type == ValueType::Unit);
    cleanup(r);
}

TEST_CASE(result_builtins_positive_paths) {
    RunResult r = run(
        "let ok = Ok(5);"
        "let is_ok_result = is_ok(ok);"
        "let unwrapped = unwrap(ok);"
        "let err = Err(\"bad\");"
        "let is_err_result = is_err(err);"
        "let unwrapped_err = unwrap_err(err);");
    CHECK(r.diags.empty());
    CHECK(global(r, "is_ok_result")->bool_val);
    CHECK_EQ(global(r, "unwrapped")->i32_val, 5);
    CHECK(global(r, "is_err_result")->bool_val);
    CHECK_EQ(global(r, "unwrapped_err")->string_val, std::string("bad"));
    cleanup(r);
}

TEST_CASE(unwrap_on_wrong_variant_or_non_result_is_a_diagnostic) {
    RunResult r = run(
        "let err = Err(1);"
        "let a = unwrap(err);"    // wrong variant
        "let b = unwrap(5);");    // not a Result at all
    CHECK_EQ(r.diags.size(), static_cast<size_t>(2));
    CHECK(global(r, "a")->type == ValueType::Unit);
    CHECK(global(r, "b")->type == ValueType::Unit);
    cleanup(r);
}

TEST_CASE(undefined_function_call_is_a_diagnostic_not_a_crash) {
    RunResult r = run("let x = thisDoesNotExist(1, 2);");
    CHECK_EQ(r.diags.size(), static_cast<size_t>(1));
    cleanup(r);
}

TINYTEST_MAIN()
