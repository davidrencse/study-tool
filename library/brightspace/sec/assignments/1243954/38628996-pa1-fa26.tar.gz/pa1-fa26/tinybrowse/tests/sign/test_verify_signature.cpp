#include "tinytest.h"

#include <fstream>
#include <sstream>
#include <string>

#include "net/fixture_server.h"
#include "net/http_client.h"
#include "sign/verify_signature.h"

using namespace sign;

namespace {

// A real body/digest/signature triple, generated offline against
// tests/sign/fixtures/pki/leaf_key.pem:
//   printf '%s' "$BODY" > body.txt
//   openssl dgst -sha256 -binary body.txt | openssl base64 -A       # digest
//   openssl dgst -sha256 -sign leaf_key.pem body.txt | openssl base64 -A  # signature
const char kBody[] = "Hello, this is a signed tinybrowse page.\n";
const char kDigestB64[] = "zFNkTFEd9n/dj/774Ez6YstZYWaLzNncDqiY8dq0yz4=";
const char kSignatureB64[] =
    "MEUCICsv8bYctzoDm8S1NS1GOcV1hpyr3LLpRQaj9rvKzzrgAiEA3t50xFDaaB7+"
    "uNFDknKxCVBO18NNHpxqURBDYzLqtOc=";

bool read_file(const std::string& path, std::string* out) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        return false;
    }
    std::ostringstream buffer;
    buffer << file.rdbuf();
    *out = buffer.str();
    return true;
}

std::string pki_fixture(const char* name) {
    return std::string(TINYBROWSE_SIGN_FIXTURES_DIR) + "/pki/" + name;
}

std::string http_response_for(const std::string& bytes) {
    return "HTTP/1.1 200 OK\r\nContent-Length: " + std::to_string(bytes.size()) + "\r\n\r\n" + bytes;
}

net::FetchResult make_page(const std::string& body, const std::string& digest_header_value,
                            const std::string& cert_url, const std::string& signature_b64) {
    net::FetchResult page;
    page.ok = true;
    page.status_code = 200;
    page.body = body;
    page.headers["content-digest"] = digest_header_value;
    page.headers["signature-input"] = "sig1=(\"content-digest\");cert-url=\"" + cert_url + "\"";
    page.headers["signature"] = "sig1=:" + signature_b64 + ":";
    return page;
}

std::string digest_header() {
    return std::string("sha-256=:") + kDigestB64 + ":";
}

// Not fetched by the digest-mismatch/malformed-header cases (verify_signature
// returns before ever looking at cert-url), so this doesn't need to resolve.
const char kUnusedCertUrl[] = "http://127.0.0.1:1/unused.der";

}  // namespace

TEST_CASE(valid_signature_passes) {
    std::string leaf_der;
    CHECK(read_file(pki_fixture("leaf_cert.der"), &leaf_der));
    FixtureServer server;
    server.serve_once(http_response_for(leaf_der));

    std::string cert_url = "http://127.0.0.1:" + std::to_string(server.port()) + "/leaf.der";
    net::FetchResult page = make_page(kBody, digest_header(), cert_url, kSignatureB64);

    CHECK(verify_signature(page) == VerifyResult::Ok);
}

TEST_CASE(tampered_body_fails_with_digest_mismatch) {
    net::FetchResult page =
        make_page(std::string(kBody) + "extra bytes", digest_header(), kUnusedCertUrl, kSignatureB64);
    CHECK(verify_signature(page) == VerifyResult::DigestMismatch);
}

TEST_CASE(tampered_signature_fails) {
    std::string leaf_der;
    CHECK(read_file(pki_fixture("leaf_cert.der"), &leaf_der));
    FixtureServer server;
    server.serve_once(http_response_for(leaf_der));

    std::string cert_url = "http://127.0.0.1:" + std::to_string(server.port()) + "/leaf.der";
    std::string tampered_signature = kSignatureB64;
    // Flip a character within the base64 payload (not the padding) so it
    // stays valid base64 but decodes to a different signature.
    tampered_signature[10] = (tampered_signature[10] == 'A') ? 'B' : 'A';
    net::FetchResult page = make_page(kBody, digest_header(), cert_url, tampered_signature);

    CHECK(verify_signature(page) == VerifyResult::BadSignature);
}

TEST_CASE(cert_not_chaining_to_the_pinned_root_fails) {
    // Phase 0's throwaway self-signed cert -- unrelated to tinybrowse's
    // pinned root, so chain verification must fail before signature
    // verification is even attempted.
    std::string unrelated_der;
    CHECK(read_file(std::string(TINYBROWSE_SIGN_FIXTURES_DIR) + "/smoke_cert.der", &unrelated_der));
    FixtureServer server;
    server.serve_once(http_response_for(unrelated_der));

    std::string cert_url = "http://127.0.0.1:" + std::to_string(server.port()) + "/leaf.der";
    net::FetchResult page = make_page(kBody, digest_header(), cert_url, kSignatureB64);

    CHECK(verify_signature(page) == VerifyResult::UntrustedCert);
}

TEST_CASE(malformed_der_cert_fails_cleanly_instead_of_crashing) {
    FixtureServer server;
    server.serve_once(http_response_for("this is not a certificate"));

    std::string cert_url = "http://127.0.0.1:" + std::to_string(server.port()) + "/leaf.der";
    net::FetchResult page = make_page(kBody, digest_header(), cert_url, kSignatureB64);

    CHECK(verify_signature(page) == VerifyResult::MalformedCert);
}

TEST_CASE(truncated_der_cert_fails_cleanly_instead_of_crashing) {
    std::string leaf_der;
    CHECK(read_file(pki_fixture("leaf_cert.der"), &leaf_der));
    leaf_der.resize(leaf_der.size() / 2);
    FixtureServer server;
    server.serve_once(http_response_for(leaf_der));

    std::string cert_url = "http://127.0.0.1:" + std::to_string(server.port()) + "/leaf.der";
    net::FetchResult page = make_page(kBody, digest_header(), cert_url, kSignatureB64);

    CHECK(verify_signature(page) == VerifyResult::MalformedCert);
}

TEST_CASE(cert_fetch_failure_fails_cleanly) {
    int port = unused_port();
    std::string cert_url = "http://127.0.0.1:" + std::to_string(port) + "/leaf.der";
    net::FetchResult page = make_page(kBody, digest_header(), cert_url, kSignatureB64);

    CHECK(verify_signature(page) == VerifyResult::CertFetchFailed);
}

TEST_CASE(page_with_no_signature_headers_is_not_signed) {
    net::FetchResult page;
    page.ok = true;
    page.status_code = 200;
    page.body = kBody;
    CHECK(verify_signature(page) == VerifyResult::NotSigned);
}

TEST_CASE(signature_input_missing_cert_url_fails_with_malformed_headers) {
    net::FetchResult page;
    page.ok = true;
    page.status_code = 200;
    page.body = kBody;
    page.headers["content-digest"] = digest_header();
    page.headers["signature-input"] = "sig1=(\"content-digest\")";  // no cert-url param
    page.headers["signature"] = std::string("sig1=:") + kSignatureB64 + ":";

    CHECK(verify_signature(page) == VerifyResult::MalformedHeaders);
}

TEST_CASE(signature_header_without_sig1_wrapper_fails_with_malformed_headers) {
    net::FetchResult page = make_page(kBody, digest_header(), kUnusedCertUrl, kSignatureB64);
    page.headers["signature"] = kSignatureB64;  // missing the "sig1=:...:" wrapper

    CHECK(verify_signature(page) == VerifyResult::MalformedHeaders);
}

TINYTEST_MAIN()
