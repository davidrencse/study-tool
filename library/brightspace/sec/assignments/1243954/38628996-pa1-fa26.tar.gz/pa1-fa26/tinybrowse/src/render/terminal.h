#pragma once

#include <iostream>
#include <vector>

#include "render/layout.h"

namespace render {

// Writes `lines` to `out` (stdout by default), one per line.
void print_to_terminal(const std::vector<Line>& lines, std::ostream& out = std::cout);

}  // namespace render
