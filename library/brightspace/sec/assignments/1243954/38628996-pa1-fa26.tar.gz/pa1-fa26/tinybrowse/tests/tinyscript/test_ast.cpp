#include "tinytest.h"

#include "tinyscript/ast.h"

using namespace tinyscript;

TEST_CASE(free_program_frees_nested_tree_without_crashing) {
    // Builds the tree for `1 + 2;` by hand and checks free_program()
    // walks and frees all of it without crashing (run this test under
    // ASan/valgrind once those are wired in, to also check for leaks).
    Expr* left = new Expr{};
    left->type = ExprType::Number;
    left->number = 1;

    Expr* right = new Expr{};
    right->type = ExprType::Number;
    right->number = 2;

    Expr* sum = new Expr{};
    sum->type = ExprType::Binary;
    sum->text = "+";
    sum->left = left;
    sum->right = right;

    Stmt* expr_stmt = new Stmt{};
    expr_stmt->type = StmtType::ExprStmt;
    expr_stmt->expr = sum;

    Program program;
    program.statements.push_back(expr_stmt);

    free_program(program);
    CHECK(program.statements.empty());
}

TINYTEST_MAIN()
