#pragma once

#include <string>

namespace tinyhtml {

// See docs/tinyhtml-spec.md section 1 (Lexical grammar).
enum class TokenType {
    TagOpen,       // "<" IDENT, e.g. the start of "<p"
    TagClose,      // "</" IDENT ">"
    TagEnd,        // ">"
    TagSelfClose,  // "/>"
    Ident,
    String,
    Equals,
    Text,
    EndOfFile,
};

struct Token {
    TokenType type;
    std::string text;  // decoded payload; empty for pure-punctuation tokens
    int line;
};

}  // namespace tinyhtml
