#include "tinytest.h"

#include <string>

#include "browser/browser.h"
#include "net/fixture_server.h"

namespace {

std::string url_for(const FixtureServer& server) {
    return "http://127.0.0.1:" + std::to_string(server.port()) + "/";
}

// Same real body/digest/signature triple as tests/sign/test_verify_signature.cpp
// (generated offline against tests/sign/fixtures/pki/leaf_key.pem).
const char kSignedBody[] = "Hello, this is a signed tinybrowse page.\n";
const char kDigestHeader[] = "sha-256=:zFNkTFEd9n/dj/774Ez6YstZYWaLzNncDqiY8dq0yz4=:";
const char kSignatureB64[] =
    "MEUCICsv8bYctzoDm8S1NS1GOcV1hpyr3LLpRQaj9rvKzzrgAiEA3t50xFDaaB7+"
    "uNFDknKxCVBO18NNHpxqURBDYzLqtOc=";

std::string leaf_cert_der() {
    std::string der;
    browser::read_file(std::string(TINYBROWSE_SIGN_FIXTURES_DIR) + "/pki/leaf_cert.der", der);
    return der;
}

std::string http_response_for(const std::string& bytes) {
    return "HTTP/1.1 200 OK\r\nContent-Length: " + std::to_string(bytes.size()) + "\r\n\r\n" + bytes;
}

std::string signed_page_response(const std::string& body, const std::string& digest_header,
                                  const std::string& cert_url, const std::string& signature_b64) {
    std::string headers = "HTTP/1.1 200 OK\r\nContent-Length: " + std::to_string(body.size()) +
                           "\r\nContent-Digest: " + digest_header +
                           "\r\nSignature-Input: sig1=(\"content-digest\");cert-url=\"" + cert_url +
                           "\"\r\nSignature: sig1=:" + signature_b64 + ":\r\n\r\n";
    return headers + body;
}

}  // namespace

// The render/tinyscript pipeline itself is exercised by render_test_layout
// and browser_test_dialect; these cases only check the new wiring --
// fetch a document over the network and drive it through load_and_render's
// existing tail -- succeeds or fails cleanly.

TEST_CASE(load_and_render_url_succeeds_for_a_fetched_page) {
    FixtureServer server;
    std::string body = "<title>T</title><p>hi</p>";
    server.serve_once("HTTP/1.1 200 OK\r\nContent-Length: " + std::to_string(body.size()) + "\r\n\r\n" + body);

    CHECK_EQ(browser::load_and_render_url(url_for(server)), 0);
}

TEST_CASE(load_and_render_url_still_renders_a_non_2xx_response) {
    FixtureServer server;
    std::string body = "<p>not found</p>";
    server.serve_once("HTTP/1.1 404 Not Found\r\nContent-Length: " + std::to_string(body.size()) + "\r\n\r\n" +
                       body);

    CHECK_EQ(browser::load_and_render_url(url_for(server)), 0);
}

TEST_CASE(load_and_render_url_fails_cleanly_when_connection_is_refused) {
    int port = unused_port();
    CHECK_EQ(browser::load_and_render_url("http://127.0.0.1:" + std::to_string(port) + "/"), 1);
}

TEST_CASE(load_and_render_url_succeeds_for_a_validly_signed_page) {
    FixtureServer cert_server;
    cert_server.serve_once(http_response_for(leaf_cert_der()));
    std::string cert_url = url_for(cert_server);

    FixtureServer page_server;
    page_server.serve_once(signed_page_response(kSignedBody, kDigestHeader, cert_url, kSignatureB64));

    CHECK_EQ(browser::load_and_render_url(url_for(page_server)), 0);
}

TEST_CASE(load_and_render_url_refuses_a_page_with_a_tampered_signature) {
    FixtureServer cert_server;
    cert_server.serve_once(http_response_for(leaf_cert_der()));
    std::string cert_url = url_for(cert_server);

    std::string tampered_signature = kSignatureB64;
    tampered_signature[10] = (tampered_signature[10] == 'A') ? 'B' : 'A';

    FixtureServer page_server;
    page_server.serve_once(signed_page_response(kSignedBody, kDigestHeader, cert_url, tampered_signature));

    CHECK_EQ(browser::load_and_render_url(url_for(page_server)), 1);
}

TINYTEST_MAIN()
