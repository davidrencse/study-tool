# Examples

Hand-written `.thtml` documents to try tinybrowse's tooling against.

- `hello.thtml` — the smallest possible document: a title, a heading, a paragraph.
- `showcase.thtml` — exercises most of tinyhtml's tag set (headings, text formatting, links,
  lists, entities, nested elements) in one file.
- `tinyscript-demo.thtml` — a `<script>` block (default dialect, no annotations) showing
  implicit numeric promotion, arrays, the `Result` type, and the DOM API (`getElementById`/
  `setText`).
- `typyscript-demo.thtml` — the same ideas under `<script type="typyscript">`: explicit type
  annotations, an `Array<u32>` passed into a user-declared function, and two script blocks
  that share globals and hoist a function across tags (docs/typyscript-spec.md
  section 4).

## Viewing them

```sh
make run FILE=examples/hello.thtml            # browses the page interactively
make run FILE=examples/tinyscript-demo.thtml  # runs the script (print() and any
make run FILE=examples/typyscript-demo.thtml  # diagnostics go to stderr), then browses

make dump-dom FILE=examples/hello.thtml       # or see the parsed DOM tree directly
```

`make run` exercises the full load → parse → check (typyscript only) → run scripts → layout →
render pipeline end to end: script output (`print`) and diagnostics print to stderr first, then
the rendered page (styled with ANSI bold/italic/underline; headings, lists, and DOM mutations
from `setText` all show up) prints to stdout. Try breaking `typyscript-demo.thtml` (e.g. delete
a `: u32` annotation) to see the whole-document all-or-nothing check fail instead of just the
one bad line -- and notice the DOM mutation from that script's `setText` call never happens
either, since the whole document is rejected before anything runs.

## Browsing interactively

Loading any page -- local file or URL -- now drops into an interactive session instead of
rendering once and exiting. Every `<a href>` gets a bracketed number (`click[1]`) inline, plus
an entry in a `References` list at the end of the page (`showcase.thtml` has one to try). At the
`>` prompt:

- a bare number follows that link (relative hrefs resolve against the current page -- a local
  file's directory, or the current URL, depending on where you started)
- `b` / `back` returns to the previous page (always reloaded fresh, never cached)
- `q` / `quit`, or EOF (Ctrl+D), exits

A bad link number or a failed navigation (a broken link, a server that's down) prints an error
and leaves you exactly where you were -- it doesn't crash the session or lose your place.

For a one-shot render-and-exit instead (e.g. for scripting, or comparing output byte-for-byte),
pass `--exit-after-load`:

```sh
make run FILE=examples/hello.thtml EXTRA_ARGS=--exit-after-load
```

## Loading a page over the network

`tinybrowse` can also fetch a document with a single HTTP GET instead of reading a local file:

```sh
make run-url URL=http://127.0.0.1:8000/hello.thtml
```

This is meant for a local/controlled test server serving `.thtml` fixtures (e.g.
`python3 -m http.server 8000` from this directory), not the open internet: the client
(`src/net/`) is a small hand-rolled HTTP/1.1 GET, with no TLS, no redirects, and no chunked
transfer-encoding support -- `https://` URLs are rejected outright. Once fetched, the response
body goes through exactly the same parse → run scripts → layout → render pipeline as a file
loaded from disk, and (per above) the same interactive link-following session.
