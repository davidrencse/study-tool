#include "tinytest.h"

#include <limits>

#include "tinyscript/value.h"

using namespace tinyscript;

namespace {

// Result isn't constructible via a public helper yet (Ok/Err land as
// interpreter builtins in a later phase) -- these are white-box test
// helpers that build one directly against Value's fields.
Value make_ok(Value payload) {
    Value v;
    v.type = ValueType::Result;
    v.result_is_ok = true;
    v.payload = new Value(std::move(payload));
    return v;
}
Value make_err(Value payload) {
    Value v;
    v.type = ValueType::Result;
    v.result_is_ok = false;
    v.payload = new Value(std::move(payload));
    return v;
}

}  // namespace

TEST_CASE(is_truthy_matches_spec_falsy_values) {
    CHECK(!is_truthy(make_bool(false)));
    CHECK(!is_truthy(make_unit()));
    CHECK(!is_truthy(make_i32(0)));
    CHECK(!is_truthy(make_string("")));

    CHECK(is_truthy(make_bool(true)));
    CHECK(is_truthy(make_i32(1)));
    CHECK(is_truthy(make_string("x")));
}

TEST_CASE(result_is_always_truthy_regardless_of_contents) {
    Value ok = make_ok(make_bool(false));
    Value err = make_err(make_i32(0));
    CHECK(is_truthy(ok));
    CHECK(is_truthy(err));
    // Array truthiness is covered in test_array.cpp, alongside the rest of
    // the Array-specific behavior.
    free_value(&ok);
    free_value(&err);
}

TEST_CASE(to_display_string_formats_each_scalar_kind) {
    CHECK_EQ(to_display_string(make_string("hi")), std::string("hi"));
    CHECK_EQ(to_display_string(make_bool(true)), std::string("true"));
    CHECK_EQ(to_display_string(make_bool(false)), std::string("false"));
    CHECK_EQ(to_display_string(make_unit()), std::string("()"));
    CHECK_EQ(to_display_string(make_i32(3)), std::string("3"));
    CHECK_EQ(to_display_string(make_u8(200)), std::string("200"));
}

TEST_CASE(to_display_string_formats_result) {
    Value ok = make_ok(make_i32(5));
    Value err = make_err(make_string("bad"));
    CHECK_EQ(to_display_string(ok), std::string("Ok(5)"));
    CHECK_EQ(to_display_string(err), std::string("Err(bad)"));
    free_value(&ok);
    free_value(&err);
}

TEST_CASE(values_equal_cross_numeric_kind_promotes_like_arithmetic) {
    CHECK(values_equal(make_u8(5), make_u32(5)));
    CHECK(!values_equal(make_u8(5), make_u32(6)));
    CHECK(values_equal(make_i32(5), make_f64(5.0)));
}

TEST_CASE(values_equal_different_categories_is_always_false) {
    CHECK(!values_equal(make_i32(0), make_bool(false)));
    CHECK(!values_equal(make_string(""), make_unit()));
}

TEST_CASE(values_equal_result_is_structural) {
    Value ok5a = make_ok(make_i32(5));
    Value ok5b = make_ok(make_i32(5));
    Value err5 = make_err(make_i32(5));
    Value ok6 = make_ok(make_i32(6));

    CHECK(values_equal(ok5a, ok5b));
    CHECK(!values_equal(ok5a, err5));
    CHECK(!values_equal(ok5a, ok6));

    free_value(&ok5a);
    free_value(&ok5b);
    free_value(&err5);
    free_value(&ok6);
}

TEST_CASE(cast_int_narrowing_wraps) {
    std::vector<Diagnostic> diags;
    Value result = cast_numeric(make_u32(300), NumKind::U8, 1, &diags);
    CHECK(diags.empty());
    CHECK(result.type == ValueType::U8);
    CHECK_EQ(result.u8_val, static_cast<uint8_t>(44));
}

TEST_CASE(cast_signed_to_unsigned_reinterprets_bits) {
    std::vector<Diagnostic> diags;
    Value result = cast_numeric(make_i32(-1), NumKind::U8, 1, &diags);
    CHECK(diags.empty());
    CHECK_EQ(result.u8_val, static_cast<uint8_t>(255));
}

TEST_CASE(cast_int_widening_preserves_value) {
    std::vector<Diagnostic> diags;
    Value result = cast_numeric(make_u8(5), NumKind::U32, 1, &diags);
    CHECK_EQ(result.u32_val, static_cast<uint32_t>(5));
}

TEST_CASE(cast_float_to_int_saturates_and_maps_nan_to_zero) {
    std::vector<Diagnostic> diags;

    Value huge = cast_numeric(make_f32(1e20f), NumKind::I32, 1, &diags);
    CHECK_EQ(huge.i32_val, std::numeric_limits<int32_t>::max());

    Value neg_huge = cast_numeric(make_f32(-1e20f), NumKind::I32, 1, &diags);
    CHECK_EQ(neg_huge.i32_val, std::numeric_limits<int32_t>::min());

    Value nan_val = cast_numeric(make_f64(std::numeric_limits<double>::quiet_NaN()),
                                  NumKind::I32, 1, &diags);
    CHECK_EQ(nan_val.i32_val, 0);

    CHECK(diags.empty());  // saturation/NaN mapping is defined behavior, not an error
}

TEST_CASE(cast_of_non_numeric_value_is_a_diagnostic) {
    std::vector<Diagnostic> diags;
    Value result = cast_numeric(make_string("x"), NumKind::I32, 1, &diags);
    CHECK_EQ(diags.size(), static_cast<size_t>(1));
    CHECK(result.type == ValueType::Unit);
}

TEST_CASE(copy_value_on_result_deep_copies_payload) {
    Value original = make_ok(make_i32(5));
    Value copy = copy_value(original);

    copy.payload->i32_val = 99;
    CHECK_EQ(original.payload->i32_val, 5);   // original untouched
    CHECK_EQ(copy.payload->i32_val, 99);

    free_value(&original);
    free_value(&copy);
}

TEST_CASE(move_assignment_leaves_source_empty_no_double_ownership) {
    Value original = make_ok(make_i32(5));
    Value* original_payload = original.payload;

    Value moved = std::move(original);
    CHECK(moved.payload == original_payload);
    CHECK(original.payload == nullptr);  // ownership transferred, not aliased

    free_value(&moved);
    free_value(&original);  // no-op: payload is already null, not a double-free
}

TINYTEST_MAIN()
