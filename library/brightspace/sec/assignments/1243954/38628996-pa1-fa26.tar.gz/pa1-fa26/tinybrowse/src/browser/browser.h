#pragma once

#include <string>
#include <vector>

#include "net/http_client.h"
#include "render/layout.h"
#include "tinyhtml/dom.h"
#include "tinyscript/diagnostic.h"

namespace browser {

// The outcome of applying tinybrowse's signed-page policy (opt-in,
// fail-closed -- see docs on check_signature below) to one fetched URL.
struct SignatureCheck {
    bool ok;             // false means: refuse to render this page at all
    std::string message; // non-empty on both success and failure, for the
                          // caller to show; empty for an ordinary unsigned
                          // page (the common case -- nothing to announce)
};

// Applies sign::verify_signature to `result` and turns its VerifyResult
// into a render/refuse decision: an unsigned page (no Content-Digest
// header at all) passes through unchanged; a page that attempts to sign
// but fails any check is refused (fail-closed -- a dangerous dependency's
// negative verdict blocks rendering, it doesn't just get noted); a page
// that verifies successfully passes with a confirmation message. Shared
// by load_and_render_url and repl.cpp's load_location so both entry points
// apply the exact same policy.
SignatureCheck check_signature(const net::FetchResult& result);

// Reads the whole contents of the file at `path` into `out`. Returns
// false (leaving `out` unspecified) if the file can't be opened. Exposed
// (not just used internally by load_and_render) so repl.cpp's local-file
// navigation reads pages the same way the one-shot path does.
bool read_file(const std::string& path, std::string& out);

// Loads the tinyhtml document at `path`, runs its scripts, lays it out,
// and prints it to stdout. Returns a process exit code (0 on success).
int load_and_render(const std::string& path);

// Same as load_and_render, but fetches the document with a single HTTP GET
// (net::fetch -- http:// only, see src/net/http_client.h) instead of
// reading a local file. A non-2xx status still renders the response body
// (mirroring a real browser showing a 404 page), noted on stderr. Applies
// check_signature before rendering: an unsigned page renders as usual, a
// signed-and-verified page renders with a confirmation on stderr, and a
// page that attempts to sign but fails verification is refused entirely
// (exit code 1, nothing rendered).
int load_and_render_url(const std::string& url);

// Parses `source` as tinyhtml, runs its scripts (see run_scripts), and
// lays the resulting document out. Parse/script diagnostics print to
// stderr as a side effect; the returned LayoutResult is left for the
// caller to print -- load_and_render{,_url} print it to stdout, and
// run_repl (repl.h) prints it to whatever stream the session is using.
// Exposed for exactly that reuse, not just load_and_render{,_url}.
render::LayoutResult render_document_source(const std::string& source);

// Parses, (for typyscript) checks, and runs every <script> block in
// `document`, in document order, against one shared Interpreter -- see
// docs/tinyscript-spec.md section 8 and docs/
// typyscript-spec.md section 4 (dialect selection, all-or-nothing
// checking). Exposed (not just used internally by load_and_render) so
// tests can call it directly and inspect both the returned diagnostics
// and `document`'s resulting state, instead of scraping stdout/stderr.
std::vector<tinyscript::Diagnostic> run_scripts(tinyhtml::Node* document);

}  // namespace browser
