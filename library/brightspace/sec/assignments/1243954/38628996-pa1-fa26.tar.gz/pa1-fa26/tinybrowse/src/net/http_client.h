#pragma once

#include <map>
#include <string>

namespace net {

// Hard cap on combined header+body bytes read for one response. Exposed
// (not just an implementation detail) so tests can construct a response
// right at the boundary without duplicating the number.
constexpr size_t kMaxResponseBytes = 8 * 1024 * 1024;

struct FetchResult {
    bool ok;
    std::string error;  // set iff !ok

    int status_code;    // valid iff ok
    std::string body;   // valid iff ok

    // Response headers, valid iff ok. Keys are lowercased for
    // case-insensitive lookup (HTTP header names are case-insensitive); if
    // a header is repeated, the first occurrence wins.
    std::map<std::string, std::string> headers;
};

// Fetches `url` with a single HTTP/1.1 GET, sent with "Connection: close".
// Hand-rolled over POSIX sockets: no TLS (https:// is rejected by
// parse_url), no redirects, no chunked transfer-encoding -- see
// docs/ARCHITECTURE.md. Framing: if the response has a Content-Length
// header, exactly that many body bytes are read; otherwise the body is
// whatever arrives before the peer closes the connection. Bounded by a
// fixed response-size cap and a fixed connect/read timeout; never throws,
// never blocks indefinitely.
FetchResult fetch(const std::string& url);

}  // namespace net
