#pragma once

#include <string>

namespace net {

struct Url {
    std::string host;
    int port;
    std::string path;  // always starts with '/', query string left as-is
};

// Parses a "http://host[:port]/path" URL. Only the http scheme is
// supported (see docs/ARCHITECTURE.md -- no TLS in this client). Returns
// false, leaving *out unspecified, if the scheme is missing/unsupported,
// the host is empty, or the port isn't a valid 1-65535 integer.
bool parse_url(const std::string& url, Url* out);

// Resolves an <a href> found on the page at `base` (an absolute http://
// URL) into an absolute URL, per the cases a hand-written .thtml page
// needs: an absolute "http://..." href is returned as-is; a root-relative
// href ("/x") keeps base's host/port; anything else is joined onto base's
// directory, with "." and ".." segments collapsed. Returns false, leaving
// *out unspecified, if `base` doesn't parse or `href` looks like it has
// some other scheme (contains ':' before the first '/' -- "https:",
// "mailto:", "javascript:", etc., none of which this client supports).
// Doesn't handle protocol-relative ("//host/path") hrefs, and leaves any
// "?query"/"#fragment" in `href` untouched.
bool resolve_url(const std::string& base, const std::string& href, std::string* out);

}  // namespace net
