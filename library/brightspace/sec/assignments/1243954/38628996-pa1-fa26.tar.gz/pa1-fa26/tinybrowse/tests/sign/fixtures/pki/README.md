Offline test PKI for the signed-page feature. None of this is generated at
build time -- it's fixture material, checked in so the chain is
reproducible and inspectable. `root_cert.der`'s bytes are hand-copied into
`src/sign/trust_anchor.cpp` as tinybrowse's pinned trust anchor; if the root
keypair here is ever regenerated, that array must be updated to match.

Root (self-signed, EC P-256, CA:true) and a leaf signed by it (CA:false),
generated with:

```sh
# Root
openssl ecparam -name prime256v1 -genkey -noout -out root_key.pem
openssl req -new -x509 -key root_key.pem -out root_cert.pem -days 7300 \
  -subj "/CN=tinybrowse-pinned-root" \
  -addext "basicConstraints=critical,CA:true" \
  -addext "keyUsage=critical,keyCertSign,cRLSign"
openssl x509 -in root_cert.pem -outform DER -out root_cert.der

# Leaf
openssl ecparam -name prime256v1 -genkey -noout -out leaf_key.pem
openssl req -new -key leaf_key.pem -out leaf.csr -subj "/CN=tinybrowse-signed-page"
openssl x509 -req -in leaf.csr -CA root_cert.pem -CAkey root_key.pem -CAcreateserial \
  -out leaf_cert.pem -days 3650 \
  -copy_extensions none \
  -extfile <(printf "basicConstraints=critical,CA:false\nkeyUsage=critical,digitalSignature\n")
openssl x509 -in leaf_cert.pem -outform DER -out leaf_cert.der
```

`root_key.pem`/`leaf_key.pem` are here only so this chain can be
regenerated or extended (e.g. minting more leaves for later-phase tests);
this is test fixture material for a course project, not a secret worth
protecting the way a real CA key would be.
