#pragma once

#include <string>

#include "mbedtls/x509_crt.h"

namespace sign {

// Parses tinybrowse's baked-in pinned root certificate (regenerated via
// tests/sign/fixtures/pki/ -- see the README there) into `out`. `out` must
// already be initialized with mbedtls_x509_crt_init(); the caller owns it
// and is responsible for calling mbedtls_x509_crt_free() on it. This is the
// sole trust anchor a signed page's certificate chain is checked against
// (docs on the "signed page" feature: a single pinned root, not a CA
// chain/store) -- returns an mbedtls error code (0 on success).
//
// Native-mbedtls convenience, used by tests that want to inspect the root
// directly; verify_signature.cpp does not use this (it parses the root
// inside the sandbox instead, via trust_anchor_der() below).
int load_trust_anchor(mbedtls_x509_crt* out);

// The pinned root's raw DER bytes, for callers (verify_signature.cpp) that
// need to copy them into a sandbox and parse them there rather than parsing
// natively.
const std::string& trust_anchor_der();

}  // namespace sign
