#pragma once

#include <string>
#include <vector>

#include "tinyscript/numeric.h"
#include "tinyscript/type.h"

namespace tinyscript {

// See docs/tinyscript-spec.md section 2 (Context-free grammar) and
// docs/typyscript-spec.md section 1 (the annotation grammar delta
// both dialects share). Like tinyhtml's DOM (tinyhtml/dom.h), these are
// tagged structs rather than a class hierarchy, and are raw-pointer owned
// per docs/STYLE.md.

enum class ExprType {
    Number,
    String,
    Bool,
    Ident,
    Unary,
    Binary,
    Call,
    Cast,
    ArrayLiteral,
    Index,
};

struct Expr {
    ExprType type;
    int line = 0;

    // Number literal
    double number = 0;                   // the literal's value
    NumKind literal_kind = NumKind::I32;  // implied (i32/f32) or suffixed kind
    bool literal_kind_explicit = false;   // true iff a suffix was written

    // Bool literal
    bool boolean = false;

    // String literal contents, Ident name, or the operator token's text
    // (Unary/Binary)
    std::string text;

    // Unary: only `left` is used. Binary: both. Call: `left` is the
    // callee expression (an Ident naming a builtin or declared function)
    // and `args` are the call arguments.
    Expr* left = nullptr;
    Expr* right = nullptr;
    std::vector<Expr*> args;

    // Cast: `x as <kind>`
    Expr* cast_operand = nullptr;
    NumKind cast_target = NumKind::I32;

    // ArrayLiteral: `[e1, e2, ...]`
    std::vector<Expr*> array_elements;

    // Index: `arr[i]` -- index_array is `arr`, index_expr is `i`
    Expr* index_array = nullptr;
    Expr* index_expr = nullptr;
};

enum class StmtType { VarDecl, Assign, If, While, FuncDecl, Return, ExprStmt, Block };

struct Stmt {
    StmtType type;
    int line = 0;

    // VarDecl
    std::string var_name;
    Expr* var_init = nullptr;             // nullptr if no initializer
    Type* var_type_annotation = nullptr;  // nullptr if omitted (legal in tinyscript)

    // Assign: exactly one of these two is set, depending on the parsed
    // Lvalue form (docs/tinyscript-spec.md section 2's `Lvalue`
    // production)
    std::string assign_name;              // set when the target is a bare identifier
    Expr* assign_index_target = nullptr;  // owned; set when the target is `expr[index]`
                                           // (itself an ExprType::Index node)

    // If / While: `expr` is the condition, `body` the then/loop body.
    // FuncDecl / Block: `body` is the function/block's statement list.
    std::vector<Stmt*> body;
    std::vector<Stmt*> else_body;  // If only

    // FuncDecl
    std::string func_name;
    std::vector<std::string> param_names;
    std::vector<Type*> param_type_annotations;  // parallel to param_names; entries may be nullptr
    Type* return_type_annotation = nullptr;     // nullptr = arrow omitted entirely

    // Return / ExprStmt / If (condition) / While (condition): the one Expr*
    // this statement kind needs.
    Expr* expr = nullptr;
};

struct Program {
    std::vector<Stmt*> statements;
};

// Recursively frees an Expr/Stmt tree, including anything it owns
// transitively. Call exactly once per tree.
void free_expr(Expr* expr);
void free_stmt(Stmt* stmt);
void free_program(Program& program);

}  // namespace tinyscript
