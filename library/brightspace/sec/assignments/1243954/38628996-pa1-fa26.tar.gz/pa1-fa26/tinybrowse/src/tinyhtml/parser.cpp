#include "tinyhtml/parser.h"

#include <unordered_set>
#include <utility>

#include "tinyhtml/lexer.h"

namespace tinyhtml {

namespace {

// docs/tinyhtml-spec.md section 6: a document nested past this depth
// is rejected with a diagnostic instead of recursing further.
constexpr int kMaxNestingDepth = 512;

bool is_known_tag(const std::string& name) {
    static const std::unordered_set<std::string> kTags = {
        "h1", "h2", "h3", "p", "b", "i", "u", "a", "div",
        "span", "ul", "ol", "li", "script", "title", "br",
    };
    return kTags.count(name) > 0;
}

bool is_void_tag(const std::string& name) { return name == "br"; }

// Recursive-descent parser over the token stream. See docs/
// tinyhtml-spec.md section 2 for the grammar this implements.
struct Parser {
    std::vector<Token> tokens;
    size_t pos = 0;
    std::vector<Diagnostic>* diags;
    bool seen_title = false;

    Parser(std::vector<Token> toks, std::vector<Diagnostic>* d)
        : tokens(std::move(toks)), diags(d) {}

    const Token& peek() const { return tokens[pos]; }  // tokens always ends in EndOfFile

    const Token& advance() {
        const Token& t = tokens[pos];
        if (t.type != TokenType::EndOfFile) {
            ++pos;
        }
        return t;
    }

    bool check(TokenType type) const { return peek().type == type; }
    bool at_end() const { return check(TokenType::EndOfFile); }

    void error(const std::string& message) {
        diags->push_back(Diagnostic{message, peek().line});
    }

    Node* parse_document() {
        Node* doc = make_node(NodeType::Document);
        while (!at_end()) {
            Node* child = parse_node(0);
            if (child != nullptr) {
                append_child(doc, child);
            } else if (!at_end()) {
                advance();  // guarantee forward progress on unrecognized input
            }
        }
        return doc;
    }

    // Returns nullptr (with a diagnostic already recorded) if the current
    // token can't start a Node at all.
    Node* parse_node(int depth) {
        if (check(TokenType::Text)) {
            Node* text = make_node(NodeType::Text);
            text->text = advance().text;
            return text;
        }
        if (check(TokenType::TagOpen)) {
            return parse_element(depth);
        }
        error("expected text or an opening tag");
        return nullptr;
    }

    Node* parse_element(int depth) {
        if (depth > kMaxNestingDepth) {
            error("maximum nesting depth exceeded");
            advance();  // consume the TagOpen so the caller still makes progress
            return nullptr;
        }

        Token open = advance();  // TagOpen; text is the tag name
        const std::string& tag_name = open.text;
        if (!is_known_tag(tag_name)) {
            error("unknown tag '<" + tag_name + ">'");
        }
        if (tag_name == "title") {
            if (seen_title) {
                error("duplicate <title> element; the first one found is used");
            }
            seen_title = true;
        }

        Node* element = make_node(NodeType::Element);
        element->tag_name = tag_name;
        parse_attributes(element);

        bool self_closing = false;
        if (check(TokenType::TagSelfClose)) {
            advance();
            self_closing = true;
        } else if (check(TokenType::TagEnd)) {
            advance();
        } else {
            error("expected '>' or '/>' to close tag '<" + tag_name + ">'");
            self_closing = true;  // can't trust what follows; don't parse children
        }

        if (is_void_tag(tag_name)) {
            return element;  // void elements never have children or a closing tag
        }
        if (self_closing) {
            if (tag_name != "br") {
                error("tag '<" + tag_name + ">' cannot self-close");
            }
            return element;
        }

        if (tag_name == "script") {
            if (check(TokenType::Text)) {
                Node* text = make_node(NodeType::Text);
                text->text = advance().text;
                append_child(element, text);
            }
            expect_close(tag_name);
            return element;
        }

        while (!at_end() && !check(TokenType::TagClose)) {
            Node* child = parse_node(depth + 1);
            if (child != nullptr) {
                append_child(element, child);
            } else if (!at_end()) {
                advance();
            }
        }
        expect_close(tag_name);
        return element;
    }

    void parse_attributes(Node* element) {
        std::unordered_set<std::string> seen_names;
        Attribute* tail = nullptr;
        while (check(TokenType::Ident)) {
            Token name_tok = advance();
            if (seen_names.count(name_tok.text) != 0) {
                error("duplicate attribute '" + name_tok.text + "'");
            }
            seen_names.insert(name_tok.text);

            std::string value;
            if (check(TokenType::Equals)) {
                advance();
                if (check(TokenType::String)) {
                    value = advance().text;
                } else {
                    error("expected a quoted value after '=' for attribute '" +
                          name_tok.text + "'");
                }
            } else {
                error("expected '=' after attribute name '" + name_tok.text + "'");
            }

            Attribute* attr = new Attribute{name_tok.text, value, nullptr};
            if (tail == nullptr) {
                element->attributes = attr;
            } else {
                tail->next = attr;
            }
            tail = attr;
        }
    }

    void expect_close(const std::string& tag_name) {
        if (!check(TokenType::TagClose)) {
            error("expected closing tag '</" + tag_name + ">'");
            return;
        }
        const Token& close = peek();
        if (close.text != tag_name) {
            error("mismatched closing tag: expected '</" + tag_name +
                  ">', found '</" + close.text + ">'");
        }
        advance();
    }
};

}  // namespace

ParseResult parse(const std::string& source) {
    ParseResult result;
    Parser parser(lex(source), &result.diagnostics);
    result.document = parser.parse_document();
    return result;
}

}  // namespace tinyhtml
