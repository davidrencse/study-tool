#include "tinytest.h"

#include "net/url.h"

using namespace net;

TEST_CASE(parses_host_and_defaults_to_port_80_and_root_path) {
    Url url;
    CHECK(parse_url("http://example.com", &url));
    CHECK_EQ(url.host, std::string("example.com"));
    CHECK_EQ(url.port, 80);
    CHECK_EQ(url.path, std::string("/"));
}

TEST_CASE(parses_explicit_port_and_path) {
    Url url;
    CHECK(parse_url("http://127.0.0.1:8080/a/b?c=1", &url));
    CHECK_EQ(url.host, std::string("127.0.0.1"));
    CHECK_EQ(url.port, 8080);
    CHECK_EQ(url.path, std::string("/a/b?c=1"));
}

TEST_CASE(scheme_match_is_case_insensitive) {
    Url url;
    CHECK(parse_url("HTTP://example.com/", &url));
    CHECK_EQ(url.host, std::string("example.com"));
}

TEST_CASE(rejects_missing_scheme) {
    Url url;
    CHECK(!parse_url("example.com/path", &url));
}

TEST_CASE(rejects_unsupported_scheme) {
    Url url;
    CHECK(!parse_url("https://example.com/", &url));
    CHECK(!parse_url("ftp://example.com/", &url));
}

TEST_CASE(rejects_empty_host) {
    Url url;
    CHECK(!parse_url("http:///path", &url));
    CHECK(!parse_url("http://:8080/path", &url));
}

TEST_CASE(rejects_invalid_port) {
    Url url;
    CHECK(!parse_url("http://example.com:0/", &url));
    CHECK(!parse_url("http://example.com:99999/", &url));
    CHECK(!parse_url("http://example.com:abc/", &url));
}

TEST_CASE(resolve_absolute_href_is_used_as_is) {
    std::string resolved;
    CHECK(resolve_url("http://example.com/a/b", "http://other.com/x", &resolved));
    CHECK_EQ(resolved, std::string("http://other.com/x"));
}

TEST_CASE(resolve_absolute_href_scheme_match_is_case_insensitive) {
    std::string resolved;
    CHECK(resolve_url("http://example.com/", "HTTP://other.com/x", &resolved));
    CHECK_EQ(resolved, std::string("http://other.com/x"));
}

TEST_CASE(resolve_root_relative_href_keeps_base_host_and_port) {
    std::string resolved;
    CHECK(resolve_url("http://example.com:8080/a/b", "/x/y", &resolved));
    CHECK_EQ(resolved, std::string("http://example.com:8080/x/y"));
}

TEST_CASE(resolve_sibling_relative_href_joins_onto_base_directory) {
    std::string resolved;
    CHECK(resolve_url("http://example.com/a/b.thtml", "c.thtml", &resolved));
    CHECK_EQ(resolved, std::string("http://example.com/a/c.thtml"));
}

TEST_CASE(resolve_relative_href_against_a_directory_with_no_trailing_slash) {
    // base's path has no trailing '/' after the last segment removed --
    // "http://example.com" (root, no path segments at all) is the "/" case.
    std::string resolved;
    CHECK(resolve_url("http://example.com/", "x.thtml", &resolved));
    CHECK_EQ(resolved, std::string("http://example.com/x.thtml"));
}

TEST_CASE(resolve_parent_relative_href_pops_one_segment) {
    std::string resolved;
    CHECK(resolve_url("http://example.com/a/b/c.thtml", "../d.thtml", &resolved));
    CHECK_EQ(resolved, std::string("http://example.com/a/d.thtml"));
}

TEST_CASE(resolve_parent_relative_href_cannot_pop_past_the_root) {
    std::string resolved;
    CHECK(resolve_url("http://example.com/a.thtml", "../../../x.thtml", &resolved));
    CHECK_EQ(resolved, std::string("http://example.com/x.thtml"));
}

TEST_CASE(resolve_dot_segment_is_a_no_op) {
    std::string resolved;
    CHECK(resolve_url("http://example.com/a/b.thtml", "./c.thtml", &resolved));
    CHECK_EQ(resolved, std::string("http://example.com/a/c.thtml"));
}

TEST_CASE(resolve_preserves_trailing_slash_as_a_directory_reference) {
    std::string resolved;
    CHECK(resolve_url("http://example.com/a/b.thtml", "c/", &resolved));
    CHECK_EQ(resolved, std::string("http://example.com/a/c/"));
}

TEST_CASE(resolve_leaves_query_string_on_the_relative_href_untouched) {
    std::string resolved;
    CHECK(resolve_url("http://example.com/a/b.thtml", "c.thtml?x=1", &resolved));
    CHECK_EQ(resolved, std::string("http://example.com/a/c.thtml?x=1"));
}

TEST_CASE(resolve_rejects_an_href_with_an_unsupported_scheme) {
    std::string resolved;
    CHECK(!resolve_url("http://example.com/", "https://other.com/x", &resolved));
    CHECK(!resolve_url("http://example.com/", "mailto:a@example.com", &resolved));
    CHECK(!resolve_url("http://example.com/", "javascript:alert(1)", &resolved));
}

TEST_CASE(resolve_rejects_a_malformed_base) {
    std::string resolved;
    CHECK(!resolve_url("not-a-url", "c.thtml", &resolved));
}

TINYTEST_MAIN()
