#pragma once

#include <unordered_map>
#include <vector>

#include "tinyscript/ast.h"
#include "tinyscript/diagnostic.h"
#include "tinyscript/type.h"

namespace tinyscript {

// Maps AST expression nodes to their statically-checked type, keyed by
// node identity. Populated by typecheck_document (typyscript only) --
// tinyscript expressions never get an entry, so a lookup for one always
// falls back to Any -- the checker-internal "no information" sentinel
// (docs/instructor/typyscript-design-notes.md).
using TypeTable = std::unordered_map<const Expr*, Type>;

// Returns a copy of the checked type for `expr`, or a fresh Any Type if
// `expr` has no entry (e.g. it came from a tinyscript document, which
// never runs this checker at all).
Type type_of(const TypeTable& table, const Expr* expr);

// Runs once for the WHOLE document (all-or-nothing -- docs/
// typyscript-spec.md section 4): collects every block's top-level
// function/variable signatures into one shared declaration environment
// first (required since functions/globals hoist across <script> blocks --
// docs/tinyscript-spec.md section 3), then checks every block's
// body against it, accumulating diagnostics from every block rather than
// stopping at the first failure. Returns false if there are any
// diagnostics at all, in which case the caller must not interpret ANY of
// the blocks.
bool typecheck_document(const std::vector<Program*>& blocks, TypeTable* out_table,
                         std::vector<Diagnostic>* diags);

}  // namespace tinyscript
