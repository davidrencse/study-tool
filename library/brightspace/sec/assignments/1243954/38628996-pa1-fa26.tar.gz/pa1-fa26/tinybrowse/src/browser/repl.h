#pragma once

#include <iostream>
#include <string>

namespace browser {

enum class LocationKind { File, Url };

// Where the currently-displayed page came from -- a filesystem path or an
// absolute http:// URL. Determines how a link's href on that page gets
// resolved: net::resolve_url for a Url, directory-joining for a File (see
// repl.cpp). A File page's href can itself be an absolute "http://" URL,
// switching to a Url Location; a Url page's href is always another URL.
struct Location {
    LocationKind kind;
    std::string value;
};

// Loads `start`, renders it, then drives an interactive command loop over
// `in`/`out`: a bare link number follows that link; "b"/"back" returns to
// the previous page (an in-memory history stack -- always reloaded fresh,
// no caching); "q"/"quit", or EOF on `in`, exits. A failed navigation (bad
// link number, unsupported scheme, a fetch/read error, or a page that
// attempts to sign but fails verification -- see browser::check_signature)
// prints a message to `out` and re-prompts on the current page, touching
// neither the rendered page nor history. Returns a process exit code: 0 on
// a clean exit, 1 if even `start` couldn't be loaded.
//
// `in`/`out` are parameters -- not hardcoded to std::cin/std::cout -- so
// tests can drive a full session with in-memory streams instead of a real
// terminal. browse_file/browse_url below are the production entry points.
int run_repl(const Location& start, std::istream& in, std::ostream& out);

int browse_file(const std::string& path);
int browse_url(const std::string& url);

}  // namespace browser
