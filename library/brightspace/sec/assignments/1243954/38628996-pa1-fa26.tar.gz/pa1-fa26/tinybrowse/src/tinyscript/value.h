#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

#include "tinyhtml/dom.h"
#include "tinyscript/ast.h"
#include "tinyscript/diagnostic.h"
#include "tinyscript/numeric.h"

namespace tinyscript {

// See docs/tinyscript-spec.md section 3 (Values). No generic
// "Number": every numeric Value carries exactly one of the 8 NumKind-
// tagged fields below as its type. Deliberately a separate enum from
// NumKind (tinyscript/numeric.h) and TypeKind (tinyscript/type.h) -- see
// docs/instructor/tinyscript-design-notes.md.
enum class ValueType {
    U8,
    U32,
    U64,
    I8,
    I32,
    I64,
    F32,
    F64,
    String,
    Bool,
    Unit,
    Element,
    Function,
    Result,
    Array,
};

// Flat tagged struct with every field present regardless of `type` (matches
// tinyhtml::Node's convention) rather than a C union, since a union member
// with a non-trivial type (std::string) would need manual placement-new/
// destroy for no real benefit here.
//
// See docs/instructor/tinyscript-design-notes.md for why this is raw-
// pointer owned (no smart pointers) with a deleted copy constructor,
// extending docs/STYLE.md's ownership discipline from the DOM/AST into
// runtime values -- copy_value()/free_value() below are the only sanctioned
// way to duplicate/destroy a Value's owned payload.
struct Value {
    ValueType type = ValueType::Unit;

    uint8_t u8_val = 0;
    uint32_t u32_val = 0;
    uint64_t u64_val = 0;
    int8_t i8_val = 0;
    int32_t i32_val = 0;
    int64_t i64_val = 0;
    float f32_val = 0;
    double f64_val = 0;
    bool bool_val = false;
    std::string string_val;

    tinyhtml::Node* element_val = nullptr;  // non-owning: lives in the DOM tree
    Stmt* function_decl = nullptr;          // non-owning: lives in the Program AST

    bool result_is_ok = false;  // meaningful only when type == Result
    // OWNING. Result: points to exactly 1 Value (the Ok/Err payload).
    // Array: points to a heap buffer of `array_length` contiguous Values --
    // same field, dual meaning by `type`, to avoid a second purpose-
    // specific owning pointer (see tinyscript/array.h).
    Value* payload = nullptr;
    size_t array_length = 0;  // meaningful only when type == Array

    Value() = default;
    Value(const Value&) = delete;
    Value& operator=(const Value&) = delete;

    // NOT `= default`: a raw pointer member's compiler-generated "move" is
    // just a member-wise copy of the pointer value, which would leave
    // `payload` non-null in the moved-from object too -- a silent aliasing
    // bug (both objects would believe they own the same payload, and
    // freeing both would double-free it). These are implemented for real
    // in value.cpp: copy the fields, then null out the source's owning
    // pointer so it's left in a safe, empty state.
    Value(Value&& other) noexcept;
    Value& operator=(Value&& other) noexcept;
};

// Deep-copies `src`, including (recursively) a Result's payload or every
// element of an Array. Never called implicitly -- see docs/instructor/
// tinyscript-design-notes.md.
Value copy_value(const Value& src);

// Frees `v`'s owned payload (Result: the single payload Value; Array: every
// element, then the buffer). No-op for every other ValueType. Does not
// delete `v` itself -- `v` is typically a local, a Program-lifetime global,
// or an element inside another Value/container, not independently
// heap-owned.
void free_value(Value* v);

Value make_unit();
Value make_string(std::string s);
Value make_bool(bool b);
Value make_u8(uint8_t v);
Value make_u32(uint32_t v);
Value make_u64(uint64_t v);
Value make_i8(int8_t v);
Value make_i32(int32_t v);
Value make_i64(int64_t v);
Value make_f32(float v);
Value make_f64(double v);

// True for any of the 8 numeric ValueTypes. Used by the interpreter to
// decide whether an operator's operands are eligible for promotion
// (numeric.h) before an arithmetic/comparison op runs.
bool is_numeric_value(ValueType t);

// Precondition: is_numeric_value(t). Maps a runtime ValueType to the
// matching NumKind for use with numeric.h's promotion table and cast_numeric.
NumKind numeric_kind_of(ValueType t);

// false, 0 (any numeric kind), "", and Unit are falsy; everything else --
// including any Array or Result, regardless of contents -- is truthy. See
// docs/tinyscript-spec.md section 3.
bool is_truthy(const Value& v);

// Used by the "+" string-concatenation coercion and by print().
std::string to_display_string(const Value& v);

// Per docs/tinyscript-spec.md section 3: comparing values whose
// kinds fall in different categories is always false; two numeric values
// of any kind compare by value after promotion (numeric.h); String/Bool
// compare by value; Element/Function by identity; Result/Array
// structurally (recursively).
bool values_equal(const Value& a, const Value& b);

// Casts `src` to `target`, per docs/tinyscript-spec.md section 4:
// int<->int uses wraparound (numeric.h's wrap_* primitives); float->int
// saturates with NaN->0; casting a non-numeric Value is a Diagnostic and
// the result is Unit. `line` is attached to any Diagnostic produced.
Value cast_numeric(const Value& src, NumKind target, int line,
                    std::vector<Diagnostic>* diags);

}  // namespace tinyscript
