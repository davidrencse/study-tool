#pragma once

#include "tinyhtml/dom.h"
#include "tinyscript/interpreter.h"

namespace tinyscript {

// Registers the DOM API builtins (getElementById, getAttribute,
// setAttribute, setText, setHtml, on) into `interp`, bound to `document`
// -- see docs/tinyscript-spec.md section 7. Kept as a bridge
// separate from interpreter.h/.cpp specifically so tinyscript's core
// interpreter never needs to hardcode anything DOM-specific; only this
// module does (via Interpreter::register_builtin / Interpreter::document,
// both public exactly so this file doesn't need special access).
void register_dom_api(Interpreter& interp, tinyhtml::Node* document);

}  // namespace tinyscript
