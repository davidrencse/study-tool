#pragma once

#include <string>

namespace tinyhtml {

// See docs/tinyhtml-spec.md section 4 (The DOM tree) and docs/STYLE.md
// (Memory ownership) -- this tree is raw-pointer-owned by design.
enum class NodeType { Document, Element, Text };

struct Attribute {
    std::string name;
    std::string value;
    Attribute* next = nullptr;  // singly-linked list of one element's attributes
};

struct Node {
    NodeType type;

    // valid when type == Element
    std::string tag_name;
    Attribute* attributes = nullptr;

    // valid when type == Text
    std::string text;

    // tree links; parent is nullptr only for the root Document node
    Node* parent = nullptr;
    Node* first_child = nullptr;
    Node* next_sibling = nullptr;
};

// Allocates a Node with `new`. Caller owns the result.
Node* make_node(NodeType type);

// Recursively frees `node`, its whole subtree, and every Attribute it
// owns. Call exactly once per tree, at the point where the tree's owner
// is done with it -- see docs/STYLE.md for the ownership discipline this
// module deliberately does not paper over with smart pointers.
void free_node(Node* node);

// Appends `child` as the last child of `parent`. Takes ownership of
// `child` (it becomes reachable, and will be freed, via `parent`).
void append_child(Node* parent, Node* child);

// Finds the first attribute named `name` on `node`, or nullptr if absent
// (including when `node` is not an Element).
Attribute* find_attribute(Node* node, const std::string& name);

}  // namespace tinyhtml
