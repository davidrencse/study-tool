#include "tinytest.h"

#include "tinyscript/array.h"

using namespace tinyscript;

namespace {

Value make_ok(Value payload) {
    Value v;
    v.type = ValueType::Result;
    v.result_is_ok = true;
    v.payload = new Value(std::move(payload));
    return v;
}

}  // namespace

TEST_CASE(array_new_fills_every_slot_with_unit) {
    Value arr = array_new(3);
    std::vector<Diagnostic> diags;
    CHECK_EQ(array_len(arr), static_cast<size_t>(3));
    for (int64_t i = 0; i < 3; ++i) {
        Value v = array_get(arr, i, 1, &diags);
        CHECK(v.type == ValueType::Unit);
    }
    CHECK(diags.empty());
    free_value(&arr);
}

TEST_CASE(array_is_truthy_even_when_empty) {
    Value arr = array_new(0);
    CHECK(is_truthy(arr));
    free_value(&arr);
}

TEST_CASE(get_set_round_trip_at_every_in_bounds_index_including_boundaries) {
    Value arr = array_new(4);
    std::vector<Diagnostic> diags;
    array_set(arr, 0, make_i32(10), 1, &diags);
    array_set(arr, 3, make_i32(40), 1, &diags);  // length - 1: the boundary case
    array_set(arr, 1, make_i32(20), 1, &diags);
    array_set(arr, 2, make_i32(30), 1, &diags);
    CHECK(diags.empty());

    CHECK_EQ(array_get(arr, 0, 1, &diags).i32_val, 10);
    CHECK_EQ(array_get(arr, 1, 1, &diags).i32_val, 20);
    CHECK_EQ(array_get(arr, 2, 1, &diags).i32_val, 30);
    CHECK_EQ(array_get(arr, 3, 1, &diags).i32_val, 40);
    CHECK(diags.empty());

    free_value(&arr);
}

TEST_CASE(out_of_range_read_is_a_diagnostic_and_returns_unit) {
    Value arr = array_new(3);
    std::vector<Diagnostic> diags;

    Value at_length = array_get(arr, 3, 1, &diags);  // one past the end
    CHECK(at_length.type == ValueType::Unit);
    CHECK_EQ(diags.size(), static_cast<size_t>(1));

    Value negative = array_get(arr, -1, 1, &diags);
    CHECK(negative.type == ValueType::Unit);
    CHECK_EQ(diags.size(), static_cast<size_t>(2));

    Value way_out = array_get(arr, 1000, 1, &diags);
    CHECK(way_out.type == ValueType::Unit);
    CHECK_EQ(diags.size(), static_cast<size_t>(3));

    free_value(&arr);
}

TEST_CASE(out_of_range_write_is_a_diagnostic_and_leaves_the_array_unchanged) {
    Value arr = array_new(2);
    std::vector<Diagnostic> diags;
    array_set(arr, 0, make_i32(1), 1, &diags);
    array_set(arr, 1, make_i32(2), 1, &diags);
    CHECK(diags.empty());

    // Out-of-range writes -- including one carrying an owned payload, to
    // confirm the value that couldn't be stored is freed rather than
    // leaked (run this test's target under ASan to actually verify that).
    array_set(arr, 5, make_i32(99), 1, &diags);
    array_set(arr, -1, make_ok(make_i32(1)), 1, &diags);
    CHECK_EQ(diags.size(), static_cast<size_t>(2));

    CHECK_EQ(array_get(arr, 0, 1, &diags).i32_val, 1);
    CHECK_EQ(array_get(arr, 1, 1, &diags).i32_val, 2);

    free_value(&arr);
}

TEST_CASE(overwriting_a_slot_frees_its_previous_owned_contents) {
    // Run this test's target under ASan (see the plan's verification
    // steps) to actually confirm no leak -- functionally, this just checks
    // the overwrite still behaves correctly.
    Value arr = array_new(1);
    std::vector<Diagnostic> diags;
    array_set(arr, 0, make_ok(make_i32(1)), 1, &diags);
    array_set(arr, 0, make_ok(make_i32(2)), 1, &diags);  // must free slot 0's old Result first
    CHECK(diags.empty());

    Value v = array_get(arr, 0, 1, &diags);
    CHECK(v.result_is_ok);
    CHECK_EQ(v.payload->i32_val, 2);
    free_value(&v);

    free_value(&arr);
}

TEST_CASE(copy_value_on_array_of_results_deep_copies_every_element) {
    // White-box: pokes the underlying buffer directly rather than through
    // array_get (which now always returns an independent copy) -- this is
    // specifically testing copy_value's deep-copy behavior, not array_get.
    Value arr = array_new(2);
    std::vector<Diagnostic> diags;
    array_set(arr, 0, make_ok(make_i32(1)), 1, &diags);
    array_set(arr, 1, make_ok(make_i32(2)), 1, &diags);

    Value copy = copy_value(arr);
    copy.payload[0].payload->i32_val = 99;
    CHECK_EQ(arr.payload[0].payload->i32_val, 1);  // original untouched

    free_value(&arr);
    free_value(&copy);
}

TEST_CASE(nested_arrays_free_without_double_freeing) {
    Value outer = array_new(1);
    Value inner = array_new(2);
    std::vector<Diagnostic> diags;
    array_set(inner, 0, make_i32(1), 1, &diags);
    array_set(inner, 1, make_i32(2), 1, &diags);
    array_set(outer, 0, std::move(inner), 1, &diags);
    CHECK(diags.empty());

    free_value(&outer);  // should recursively free the nested array's buffer too
}

TINYTEST_MAIN()
