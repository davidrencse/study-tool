# typyscript specification

typyscript is tinyscript (`tinyscript-spec.md`) plus mandatory type annotations, checked
before any script in the document runs. Use `<script type="typyscript">` to select it — see
`tinyhtml-spec.md` §2 for the attribute and the one-dialect-per-document rule.

Everything in `tinyscript-spec.md` — the grammar, the value model, the promotion table, the
wraparound/saturation rules, arrays, `Result`, the DOM API, the execution pipeline — applies
unchanged. This document only covers what's different: annotations become mandatory, and a
checking pass runs before interpretation.

## 1. Grammar delta

`tinyscript-spec.md`'s `TypeAnnotation` (`: Type`) and `ReturnAnnotation` (`-> Type`) are
always syntactically legal but optional there. In typyscript they are **required**: every
`let` needs a `: Type`, every function parameter needs a `: Type`, and every function needs a
`-> Type` — including a function that returns nothing, which must write `-> ()` explicitly;
omitting the arrow entirely is a checker error, not an implicit `-> ()`.

```
Type          ::= NumericKind | "String" | "Bool" | "()" | "Element"
                | "Result" "<" Type "," Type ">"
                | "Array" "<" Type ">"
NumericKind   ::= "u8" | "u32" | "u64" | "i8" | "i32" | "i64" | "f32" | "f64"
```

There is no way to write a wildcard/"any" type in this grammar — every annotation names a
concrete type.

## 2. The checking rule

A numeric literal is **flexible** until it becomes concrete: it's concrete the moment it
carries an explicit suffix (`5u8`), and otherwise adopts a concrete kind from context — the
annotation of the `let`/parameter it's assigned into, or the kind of an already-concrete value
it's directly combined with in a binary operator. `array_new(n)`'s element type is likewise
resolved from context (the annotation on the slot the call is assigned into).

Two operands that are **both already concrete** and have different kinds require an explicit
`as` before they can be combined — the checker does not apply tinyscript's implicit
promotion table on your behalf. So:

```
let a: u8 = 5;              // OK: 5 is flexible, adopts u8 from the annotation
let b: u32 = 10;            // OK: same reasoning
let c: u32 = a + b;         // REJECTED: a is concrete u8, b is concrete u32, no `as`
let c: u32 = (a as u32) + b; // OK: explicit cast makes both operands u32
let d: u8 = a + 3;          // OK: a is concrete u8, 3 is flexible, adopts u8
```

An array literal's element type is the (possibly-flexible-resolved) type of its first
element; every other element must match it exactly, under the same same-kind-requires-`as`
rule as any other binary context.

`+` also accepts two `String` operands (concatenation, result type `String`), under the same
no-implicit-conversion rule: both sides must already be `String`. Unlike tinyscript's runtime,
which auto-coerces a non-`String` operand to its display form (`tinyscript-spec.md` §3), the
checker rejects `String + <anything else>` outright — there is currently no way to spell an
explicit numeric-to-string conversion in typyscript, so building a message like `"count: " +
n` is tinyscript-only for now.

## 3. What the checker does and doesn't guarantee

The checker verifies **value-kind consistency**: that a `String` is never used where a
`u32` is expected, that both sides of an operation agree on kind (or were explicitly cast),
that a function is called with the right number and kinds of arguments, and so on.

It makes **no static claim about array bounds** — proving an index is in range at compile
time is a much bigger analysis than this checker attempts. `arr[i]` and `arr[i] = value`
type-check as long as `arr` is some `Array<T>`, `i` is any integer kind, and the value being
read/written is `T`, regardless of what `i`'s value turns out to be at runtime. That said, the
*runtime* itself checks bounds on every access (`tinyscript-spec.md` §5) — an out-of-range
index is a Diagnostic, not undefined behavior, even though the checker never tried to rule it
out ahead of time. Static checking and runtime safety are two different guarantees here, and
it's worth not conflating "this type-checked" with "this can't misbehave."

It also does not track whether an array slot has been written before it's read: a slot
allocated by `array_new` is `Unit` until you store something else there, but the checker will
let you read it as though it already holds a `T`.

## 4. Failure and dialect semantics

A typyscript document is checked as **one unit**, not script-block by script-block:

- A syntax error in *any* `<script>` block counts as a checking failure for the document.
- A function declared in one block is checkable and callable from an *earlier* block in the
  same document — declarations from every block are collected before any block's body is
  checked, matching tinyscript's own hoisting behavior.
- If there is any checking failure anywhere in the document, **no script in the document
  runs** — not even a block that individually would have passed. The document itself still
  renders, using whatever DOM tinyhtml produced from the markup alone.
- The document's dialect is fixed by the **first** `<script>` tag encountered. A later
  `<script>` tag with a disagreeing `type` attribute is treated as another checking failure —
  same consequence as above, not a special case.

## 5. Example

```html
<script type="typyscript">
let clicks: u32 = 0;

fn onBannerClick() -> () {
    clicks = clicks + 1;
    let counter: Result<Element, ()> = getElementById("counter");
    if (is_ok(counter)) {
        setText(unwrap(counter), "Clicks: " + clicks);
    }
}
</script>
<h1 id="banner" onclick="onBannerClick">Click me</h1>
<p id="counter">Clicks: 0</p>
```
