#pragma once

#include <string>

namespace tinyscript {

struct Diagnostic {
    std::string message;
    int line;
};

}  // namespace tinyscript
