#include "sign/content_digest.h"

#include "mbedtls/sha256.h"
#include "sign/base64.h"

namespace sign {

std::string compute_content_digest(const std::string& body) {
    unsigned char digest[32];
    mbedtls_sha256(reinterpret_cast<const unsigned char*>(body.data()), body.size(), digest,
                   /*is224=*/0);
    std::string raw(reinterpret_cast<const char*>(digest), sizeof(digest));
    return "sha-256=:" + base64_encode(raw) + ":";
}

}  // namespace sign
