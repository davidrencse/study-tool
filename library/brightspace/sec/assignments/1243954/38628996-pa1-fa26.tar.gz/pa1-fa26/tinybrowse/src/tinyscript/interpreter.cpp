#include "tinyscript/interpreter.h"

#include <cmath>
#include <cstdio>
#include <unordered_map>

#include "tinyscript/array.h"
#include "tinyscript/numeric.h"

namespace tinyscript {

namespace {

// Per-call execution context: which Interpreter we're running against, the
// current scope stack (innermost last), and where diagnostics go. A
// function call gets a *fresh* ExecState with scopes = {&interp.globals,
// &call_frame} -- tinyscript has no closures (docs/
// tinyscript-spec.md section 3), so a call never sees the caller's locals.
struct ExecState {
    Interpreter& interp;
    std::vector<Scope*> scopes;
    std::vector<Diagnostic>* diags;
    bool returning = false;
    Value return_value;
};

Value eval_expr(ExecState& state, Expr* expr);
void exec_stmt(ExecState& state, Stmt* stmt);
void exec_block(ExecState& state, std::vector<Stmt*>& body);

Value* lookup_variable(ExecState& state, const std::string& name) {
    for (auto it = state.scopes.rbegin(); it != state.scopes.rend(); ++it) {
        auto found = (*it)->find(name);
        if (found != (*it)->end()) {
            return &found->second;
        }
    }
    return nullptr;
}

// Resolves the array-side of an Lvalue (docs/tinyscript-spec.md
// section 2's `Lvalue` grammar) to a mutable reference into the *real*
// stored array, not a copy -- needed so `matrix[i][j] = x`-style chained
// index-assignment actually mutates the nested array. Returns nullptr on
// any error (undefined variable, non-Array value, out-of-range index);
// the diagnostic is already recorded in every such case.
Value* resolve_array_lvalue(ExecState& state, Expr* expr) {
    if (expr->type == ExprType::Ident) {
        Value* slot = lookup_variable(state, expr->text);
        if (slot == nullptr) {
            state.diags->push_back(Diagnostic{"undefined variable '" + expr->text + "'", expr->line});
        }
        return slot;
    }
    if (expr->type != ExprType::Index) {
        state.diags->push_back(Diagnostic{"invalid assignment target", expr->line});
        return nullptr;
    }
    Value* outer = resolve_array_lvalue(state, expr->index_array);
    if (outer == nullptr) {
        return nullptr;
    }
    if (outer->type != ValueType::Array) {
        state.diags->push_back(Diagnostic{"indexing a non-Array value", expr->line});
        return nullptr;
    }
    Value index_val = eval_expr(state, expr->index_expr);
    Value as_i64 = cast_numeric(index_val, NumKind::I64, expr->line, state.diags);
    free_value(&index_val);
    if (as_i64.type != ValueType::I64) {
        return nullptr;  // cast_numeric already reported "not numeric"
    }
    return array_ref(*outer, as_i64.i64_val, expr->line, state.diags);
}

// Extracts an array index from an already-evaluated numeric Value,
// reusing cast_numeric's existing safe int/float handling rather than
// duplicating it. Reports its own diagnostic (via cast_numeric) if `v`
// isn't numeric at all.
int64_t value_as_index(const Value& v, int line, std::vector<Diagnostic>* diags) {
    Value as_i64 = cast_numeric(v, NumKind::I64, line, diags);
    return (as_i64.type == ValueType::I64) ? as_i64.i64_val : 0;
}

Value negate_value(const Value& v, std::vector<Diagnostic>* diags) {
    (void)diags;  // every case below is well-defined; nothing to report
    switch (v.type) {
        case ValueType::U8:
            return make_u8(wrap_sub_u8(0, v.u8_val));
        case ValueType::U32:
            return make_u32(wrap_sub_u32(0, v.u32_val));
        case ValueType::U64:
            return make_u64(wrap_sub_u64(0, v.u64_val));
        case ValueType::I8:
            return make_i8(wrap_sub_i8(0, v.i8_val));
        case ValueType::I32:
            return make_i32(wrap_sub_i32(0, v.i32_val));
        case ValueType::I64:
            return make_i64(wrap_sub_i64(0, v.i64_val));
        case ValueType::F32:
            return make_f32(-v.f32_val);
        case ValueType::F64:
            return make_f64(-v.f64_val);
        default:
            return make_unit();
    }
}

template <typename T>
Value compare_result(const std::string& op, T a, T b) {
    if (op == "<") {
        return make_bool(a < b);
    }
    if (op == ">") {
        return make_bool(a > b);
    }
    if (op == "<=") {
        return make_bool(a <= b);
    }
    return make_bool(a >= b);  // ">="
}

// `a`/`b` are already promoted to the same `kind` (see eval_binary).
Value apply_numeric_binop(const std::string& op, const Value& a, const Value& b, NumKind kind,
                           int line, std::vector<Diagnostic>* diags) {
    if (op == "<" || op == ">" || op == "<=" || op == ">=") {
        switch (kind) {
            case NumKind::U8:
                return compare_result(op, a.u8_val, b.u8_val);
            case NumKind::U32:
                return compare_result(op, a.u32_val, b.u32_val);
            case NumKind::U64:
                return compare_result(op, a.u64_val, b.u64_val);
            case NumKind::I8:
                return compare_result(op, a.i8_val, b.i8_val);
            case NumKind::I32:
                return compare_result(op, a.i32_val, b.i32_val);
            case NumKind::I64:
                return compare_result(op, a.i64_val, b.i64_val);
            case NumKind::F32:
                return compare_result(op, a.f32_val, b.f32_val);
            case NumKind::F64:
                return compare_result(op, a.f64_val, b.f64_val);
        }
    }

    switch (kind) {
        case NumKind::U8:
            if (op == "+") return make_u8(wrap_add_u8(a.u8_val, b.u8_val));
            if (op == "-") return make_u8(wrap_sub_u8(a.u8_val, b.u8_val));
            if (op == "*") return make_u8(wrap_mul_u8(a.u8_val, b.u8_val));
            if (op == "/") return make_u8(wrap_div_u8(a.u8_val, b.u8_val, line, diags));
            return make_u8(wrap_mod_u8(a.u8_val, b.u8_val, line, diags));
        case NumKind::U32:
            if (op == "+") return make_u32(wrap_add_u32(a.u32_val, b.u32_val));
            if (op == "-") return make_u32(wrap_sub_u32(a.u32_val, b.u32_val));
            if (op == "*") return make_u32(wrap_mul_u32(a.u32_val, b.u32_val));
            if (op == "/") return make_u32(wrap_div_u32(a.u32_val, b.u32_val, line, diags));
            return make_u32(wrap_mod_u32(a.u32_val, b.u32_val, line, diags));
        case NumKind::U64:
            if (op == "+") return make_u64(wrap_add_u64(a.u64_val, b.u64_val));
            if (op == "-") return make_u64(wrap_sub_u64(a.u64_val, b.u64_val));
            if (op == "*") return make_u64(wrap_mul_u64(a.u64_val, b.u64_val));
            if (op == "/") return make_u64(wrap_div_u64(a.u64_val, b.u64_val, line, diags));
            return make_u64(wrap_mod_u64(a.u64_val, b.u64_val, line, diags));
        case NumKind::I8:
            if (op == "+") return make_i8(wrap_add_i8(a.i8_val, b.i8_val));
            if (op == "-") return make_i8(wrap_sub_i8(a.i8_val, b.i8_val));
            if (op == "*") return make_i8(wrap_mul_i8(a.i8_val, b.i8_val));
            if (op == "/") return make_i8(wrap_div_i8(a.i8_val, b.i8_val, line, diags));
            return make_i8(wrap_mod_i8(a.i8_val, b.i8_val, line, diags));
        case NumKind::I32:
            if (op == "+") return make_i32(wrap_add_i32(a.i32_val, b.i32_val));
            if (op == "-") return make_i32(wrap_sub_i32(a.i32_val, b.i32_val));
            if (op == "*") return make_i32(wrap_mul_i32(a.i32_val, b.i32_val));
            if (op == "/") return make_i32(wrap_div_i32(a.i32_val, b.i32_val, line, diags));
            return make_i32(wrap_mod_i32(a.i32_val, b.i32_val, line, diags));
        case NumKind::I64:
            if (op == "+") return make_i64(wrap_add_i64(a.i64_val, b.i64_val));
            if (op == "-") return make_i64(wrap_sub_i64(a.i64_val, b.i64_val));
            if (op == "*") return make_i64(wrap_mul_i64(a.i64_val, b.i64_val));
            if (op == "/") return make_i64(wrap_div_i64(a.i64_val, b.i64_val, line, diags));
            return make_i64(wrap_mod_i64(a.i64_val, b.i64_val, line, diags));
        case NumKind::F32:
            if (op == "+") return make_f32(a.f32_val + b.f32_val);
            if (op == "-") return make_f32(a.f32_val - b.f32_val);
            if (op == "*") return make_f32(a.f32_val * b.f32_val);
            if (op == "/") return make_f32(a.f32_val / b.f32_val);  // IEEE-754 defined, even for /0
            return make_f32(std::fmod(a.f32_val, b.f32_val));
        case NumKind::F64:
            if (op == "+") return make_f64(a.f64_val + b.f64_val);
            if (op == "-") return make_f64(a.f64_val - b.f64_val);
            if (op == "*") return make_f64(a.f64_val * b.f64_val);
            if (op == "/") return make_f64(a.f64_val / b.f64_val);
            return make_f64(std::fmod(a.f64_val, b.f64_val));
    }
    return make_unit();  // unreachable
}

Value eval_binary(ExecState& state, Expr* expr) {
    const std::string& op = expr->text;

    if (op == "&&" || op == "||") {
        Value left = eval_expr(state, expr->left);
        bool left_truthy = is_truthy(left);
        free_value(&left);
        if (op == "&&" && !left_truthy) {
            return make_bool(false);
        }
        if (op == "||" && left_truthy) {
            return make_bool(true);
        }
        Value right = eval_expr(state, expr->right);
        bool right_truthy = is_truthy(right);
        free_value(&right);
        return make_bool(right_truthy);
    }

    Value left = eval_expr(state, expr->left);
    Value right = eval_expr(state, expr->right);

    if (op == "==" || op == "!=") {
        bool eq = values_equal(left, right);
        free_value(&left);
        free_value(&right);
        return make_bool(op == "==" ? eq : !eq);
    }

    if (op == "+" && (left.type == ValueType::String || right.type == ValueType::String)) {
        std::string result = to_display_string(left) + to_display_string(right);
        free_value(&left);
        free_value(&right);
        return make_string(std::move(result));
    }

    if (!is_numeric_value(left.type) || !is_numeric_value(right.type)) {
        state.diags->push_back(
            Diagnostic{"operator '" + op + "' requires numeric operands", expr->line});
        free_value(&left);
        free_value(&right);
        if (op == "<" || op == ">" || op == "<=" || op == ">=") {
            return make_bool(false);
        }
        return make_unit();
    }

    NumKind common = promote_kind(numeric_kind_of(left.type), numeric_kind_of(right.type));
    Value pa = cast_numeric(left, common, expr->line, state.diags);
    Value pb = cast_numeric(right, common, expr->line, state.diags);
    free_value(&left);
    free_value(&right);

    Value result = apply_numeric_binop(op, pa, pb, common, expr->line, state.diags);
    free_value(&pa);
    free_value(&pb);
    return result;
}

// ---- Builtins ----
// docs/tinyscript-spec.md sections 6-7: Ok/Err/is_ok/is_err/
// unwrap/unwrap_err (Result), array_new/array_len (Array), print. The DOM
// API (getElementById etc.) is a later phase's addition (src/tinyscript/
// dom_api.h) -- calling one of those names here is just an undefined
// function until then.

Value builtin_ok(Interpreter& interp, std::vector<Value>& args, int line,
                  std::vector<Diagnostic>* diags) {
    (void)interp;
    (void)line;
    (void)diags;
    Value out;
    out.type = ValueType::Result;
    out.result_is_ok = true;
    out.payload = new Value(std::move(args[0]));
    return out;
}

Value builtin_err(Interpreter& interp, std::vector<Value>& args, int line,
                   std::vector<Diagnostic>* diags) {
    (void)interp;
    (void)line;
    (void)diags;
    Value out;
    out.type = ValueType::Result;
    out.result_is_ok = false;
    out.payload = new Value(std::move(args[0]));
    return out;
}

Value builtin_is_ok(Interpreter& interp, std::vector<Value>& args, int line,
                     std::vector<Diagnostic>* diags) {
    (void)interp;
    (void)line;
    (void)diags;
    return make_bool(args[0].type == ValueType::Result && args[0].result_is_ok);
}

Value builtin_is_err(Interpreter& interp, std::vector<Value>& args, int line,
                      std::vector<Diagnostic>* diags) {
    (void)interp;
    (void)line;
    (void)diags;
    return make_bool(args[0].type == ValueType::Result && !args[0].result_is_ok);
}

Value builtin_unwrap(Interpreter& interp, std::vector<Value>& args, int line,
                      std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Result || !args[0].result_is_ok) {
        diags->push_back(Diagnostic{"unwrap() called on a non-Ok value", line});
        return make_unit();
    }
    return copy_value(*args[0].payload);
}

Value builtin_unwrap_err(Interpreter& interp, std::vector<Value>& args, int line,
                          std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Result || args[0].result_is_ok) {
        diags->push_back(Diagnostic{"unwrap_err() called on a non-Err value", line});
        return make_unit();
    }
    return copy_value(*args[0].payload);
}

Value builtin_array_new(Interpreter& interp, std::vector<Value>& args, int line,
                         std::vector<Diagnostic>* diags) {
    (void)interp;
    int64_t n = value_as_index(args[0], line, diags);
    if (n < 0) {
        diags->push_back(Diagnostic{"array_new: length must not be negative", line});
        n = 0;
    }
    return array_new(static_cast<size_t>(n));
}

Value builtin_array_len(Interpreter& interp, std::vector<Value>& args, int line,
                         std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Array) {
        diags->push_back(Diagnostic{"array_len() called on a non-Array value", line});
        return make_u64(0);
    }
    return make_u64(array_len(args[0]));
}

Value builtin_print(Interpreter& interp, std::vector<Value>& args, int line,
                     std::vector<Diagnostic>* diags) {
    (void)interp;
    (void)line;
    (void)diags;
    std::string line_out = to_display_string(args[0]) + "\n";
    std::fprintf(stderr, line_out.c_str());
    return make_unit();
}

Value builtin_array_concat(Interpreter& interp, std::vector<Value>& args, int line,
                            std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Array || args[1].type != ValueType::Array) {
        diags->push_back(Diagnostic{"array_concat() requires two Array values", line});
        return array_new(0);
    }
    return array_concat(args[0], args[1]);
}

Value builtin_array_pop(Interpreter& interp, std::vector<Value>& args, int line,
                         std::vector<Diagnostic>* diags) {
    (void)interp;
    if (args[0].type != ValueType::Array) {
        diags->push_back(Diagnostic{"array_pop() called on a non-Array value", line});
        Value err;
        err.type = ValueType::Result;
        err.result_is_ok = false;
        err.payload = new Value();
        return err;
    }
    return array_pop(args[0], line, diags);
}

const std::unordered_map<std::string, BuiltinInfo>& core_builtins() {
    static const std::unordered_map<std::string, BuiltinInfo> table = {
        {"Ok", {1, builtin_ok}},
        {"Err", {1, builtin_err}},
        {"is_ok", {1, builtin_is_ok}},
        {"is_err", {1, builtin_is_err}},
        {"unwrap", {1, builtin_unwrap}},
        {"unwrap_err", {1, builtin_unwrap_err}},
        {"array_new", {1, builtin_array_new}},
        {"array_len", {1, builtin_array_len}},
        {"array_concat", {2, builtin_array_concat}},
        {"array_pop", {1, builtin_array_pop}},
        {"print", {1, builtin_print}},
    };
    return table;
}

// Parked fix for tinyscript's uncapped call recursion (tinyhtml caps
// nesting depth -- docs/tinyhtml-spec.md section 6 -- tinyscript
// never got an equivalent). Would be the second half of a stack switch:
// enter whatever stack is already current. First half (allocating the
// replacement stack) was never wired up.
extern "C" __attribute__((noinline, used)) void resume_on_guard_stack() {
    __asm__ volatile("jmp *%rsp");
}

Value call_user_function(ExecState& state, Stmt* func, std::vector<Value>& args, int line) {
    if (args.size() != func->param_names.size()) {
        state.diags->push_back(
            Diagnostic{"wrong number of arguments to '" + func->func_name + "'", line});
        for (Value& a : args) {
            free_value(&a);
        }
        return make_unit();
    }

    Scope call_scope;
    for (size_t i = 0; i < args.size(); ++i) {
        call_scope.emplace(func->param_names[i], std::move(args[i]));
    }

    ExecState call_state{state.interp, {&state.interp.globals, &call_scope}, state.diags, false,
                         Value()};
    for (Stmt* s : func->body) {
        exec_stmt(call_state, s);
        if (call_state.returning) {
            break;
        }
    }
    free_scope(call_scope);

    if (call_state.returning) {
        return std::move(call_state.return_value);
    }
    return make_unit();  // fell off the end without a return
}

Value eval_call(ExecState& state, Expr* expr) {
    if (expr->left == nullptr || expr->left->type != ExprType::Ident) {
        state.diags->push_back(Diagnostic{"call target must be a function name", expr->line});
        for (Expr* a : expr->args) {
            Value v = eval_expr(state, a);
            free_value(&v);
        }
        return make_unit();
    }
    const std::string& name = expr->left->text;

    std::vector<Value> args;
    args.reserve(expr->args.size());
    for (Expr* a : expr->args) {
        args.push_back(eval_expr(state, a));
    }

    const BuiltinInfo* builtin = nullptr;
    auto core_it = core_builtins().find(name);
    if (core_it != core_builtins().end()) {
        builtin = &core_it->second;
    } else {
        auto extra_it = state.interp.extra_builtins.find(name);
        if (extra_it != state.interp.extra_builtins.end()) {
            builtin = &extra_it->second;
        }
    }
    if (builtin != nullptr) {
        if (static_cast<int>(args.size()) != builtin->arity) {
            state.diags->push_back(
                Diagnostic{"wrong number of arguments to '" + name + "'", expr->line});
            for (Value& v : args) {
                free_value(&v);
            }
            return make_unit();
        }
        Value result = builtin->fn(state.interp, args, expr->line, state.diags);
        for (Value& v : args) {
            free_value(&v);  // no-op for anything the builtin moved out of
        }
        return result;
    }

    auto func_it = state.interp.functions.find(name);
    if (func_it != state.interp.functions.end()) {
        return call_user_function(state, func_it->second, args, expr->line);
    }

    state.diags->push_back(Diagnostic{"call to undefined function '" + name + "'", expr->line});
    for (Value& v : args) {
        free_value(&v);
    }
    return make_unit();
}

Value eval_expr(ExecState& state, Expr* expr) {
    switch (expr->type) {
        case ExprType::Number: {
            if (expr->literal_kind == NumKind::F32) {
                return make_f32(static_cast<float>(expr->number));
            }
            if (expr->literal_kind == NumKind::F64) {
                return make_f64(expr->number);
            }
            // Integer kind: the grammar only allows integer suffixes on
            // INT_LITERAL tokens, so expr->number is guaranteed to already
            // be an exact integer. Route through cast_numeric's int->int
            // wraparound path (not the float->int saturating path) so
            // e.g. `300u8` wraps to 44, exactly like `300 as u8` would.
            Value as_i64 = make_i64(static_cast<int64_t>(expr->number));
            return cast_numeric(as_i64, expr->literal_kind, expr->line, state.diags);
        }
        case ExprType::String:
            return make_string(expr->text);
        case ExprType::Bool:
            return make_bool(expr->boolean);
        case ExprType::Ident: {
            Value* slot = lookup_variable(state, expr->text);
            if (slot == nullptr) {
                state.diags->push_back(
                    Diagnostic{"undefined variable '" + expr->text + "'", expr->line});
                return make_unit();
            }
            return copy_value(*slot);
        }
        case ExprType::Unary: {
            Value operand = eval_expr(state, expr->left);
            if (expr->text == "!") {
                bool truthy = is_truthy(operand);
                free_value(&operand);
                return make_bool(!truthy);
            }
            if (!is_numeric_value(operand.type)) {
                state.diags->push_back(
                    Diagnostic{"unary '-' requires a numeric operand", expr->line});
                free_value(&operand);
                return make_unit();
            }
            Value result = negate_value(operand, state.diags);
            free_value(&operand);
            return result;
        }
        case ExprType::Binary:
            return eval_binary(state, expr);
        case ExprType::Call:
            return eval_call(state, expr);
        case ExprType::Cast: {
            Value operand = eval_expr(state, expr->cast_operand);
            Value result = cast_numeric(operand, expr->cast_target, expr->line, state.diags);
            free_value(&operand);
            return result;
        }
        case ExprType::ArrayLiteral: {
            std::vector<Value> elements;
            elements.reserve(expr->array_elements.size());
            for (Expr* e : expr->array_elements) {
                elements.push_back(eval_expr(state, e));
            }
            Value arr = array_new(elements.size());
            for (size_t i = 0; i < elements.size(); ++i) {
                arr.payload[i] = std::move(elements[i]);
            }
            return arr;
        }
        case ExprType::Index: {
            Value arr = eval_expr(state, expr->index_array);
            Value index_val = eval_expr(state, expr->index_expr);
            int64_t idx = value_as_index(index_val, expr->line, state.diags);
            free_value(&index_val);

            Value result;
            if (arr.type != ValueType::Array) {
                state.diags->push_back(Diagnostic{"indexing a non-Array value", expr->line});
                result = make_unit();
            } else {
                result = array_get(arr, idx, expr->line, state.diags);
            }
            free_value(&arr);
            return result;
        }
    }
    return make_unit();  // unreachable
}

void exec_block(ExecState& state, std::vector<Stmt*>& body) {
    Scope block_scope;
    state.scopes.push_back(&block_scope);
    for (Stmt* s : body) {
        exec_stmt(state, s);
        if (state.returning) {
            break;
        }
    }
    state.scopes.pop_back();
    free_scope(block_scope);
}

void exec_stmt(ExecState& state, Stmt* stmt) {
    switch (stmt->type) {
        case StmtType::VarDecl: {
            Value val = stmt->var_init != nullptr ? eval_expr(state, stmt->var_init) : make_unit();
            Scope& top = *state.scopes.back();
            auto it = top.find(stmt->var_name);
            if (it != top.end()) {
                it->second = std::move(val);  // operator= frees the old value first
            } else {
                top.emplace(stmt->var_name, std::move(val));
            }
            break;
        }
        case StmtType::Assign: {
            if (stmt->assign_index_target != nullptr) {
                Expr* index_node = stmt->assign_index_target;
                Value* arr_ref = resolve_array_lvalue(state, index_node->index_array);
                Value rhs = eval_expr(state, stmt->expr);
                if (arr_ref == nullptr) {
                    free_value(&rhs);  // diagnostic already recorded; can't store it
                    break;
                }
                Value index_val = eval_expr(state, index_node->index_expr);
                int64_t idx = value_as_index(index_val, stmt->line, state.diags);
                free_value(&index_val);
                array_set(*arr_ref, idx, std::move(rhs), stmt->line, state.diags);
            } else if (!stmt->assign_name.empty()) {
                Value* slot = lookup_variable(state, stmt->assign_name);
                Value rhs = eval_expr(state, stmt->expr);
                if (slot == nullptr) {
                    state.diags->push_back(Diagnostic{
                        "assignment to undefined variable '" + stmt->assign_name + "'", stmt->line});
                    free_value(&rhs);
                } else {
                    *slot = std::move(rhs);  // operator= frees the slot's old contents first
                }
            } else {
                // Malformed Lvalue -- the parser already recorded a
                // diagnostic. Still evaluate+free the RHS for consistent
                // side-effect behavior, then discard it.
                Value rhs = eval_expr(state, stmt->expr);
                free_value(&rhs);
            }
            break;
        }
        case StmtType::If: {
            Value cond = eval_expr(state, stmt->expr);
            bool truthy = is_truthy(cond);
            free_value(&cond);
            if (truthy) {
                exec_block(state, stmt->body);
            } else {
                exec_block(state, stmt->else_body);
            }
            break;
        }
        case StmtType::While: {
            while (true) {
                Value cond = eval_expr(state, stmt->expr);
                bool truthy = is_truthy(cond);
                free_value(&cond);
                if (!truthy) {
                    break;
                }
                exec_block(state, stmt->body);
                if (state.returning) {
                    break;
                }
            }
            break;
        }
        case StmtType::FuncDecl:
            // Hoisting already handles top-level FuncDecls (collect_functions);
            // re-registering here is a harmless no-op for those, and is what
            // makes a *nested* FuncDecl register into the same flat,
            // document-wide table too (docs/tinyscript-spec.md
            // section 3 -- there are no closures/nested-function scoping).
            state.interp.functions[stmt->func_name] = stmt;
            break;
        case StmtType::Return: {
            Value val = stmt->expr != nullptr ? eval_expr(state, stmt->expr) : make_unit();
            free_value(&state.return_value);  // in case a previous statement already set one
            state.return_value = std::move(val);
            state.returning = true;
            break;
        }
        case StmtType::ExprStmt: {
            Value val = eval_expr(state, stmt->expr);
            free_value(&val);  // the expression's value is discarded
            break;
        }
        case StmtType::Block:
            exec_block(state, stmt->body);
            break;
    }
}

}  // namespace

void register_builtin(Interpreter& interp, const std::string& name, int arity, BuiltinFn fn) {
    if (core_builtins().count(name) != 0) {
        return;  // core language names are not overridable
    }
    interp.extra_builtins[name] = BuiltinInfo{arity, fn};
}

void free_scope(Scope& scope) {
    for (auto& kv : scope) {
        free_value(&kv.second);
    }
}

void collect_functions(Interpreter& interp, Program& program) {
    for (Stmt* stmt : program.statements) {
        if (stmt->type == StmtType::FuncDecl) {
            interp.functions[stmt->func_name] = stmt;
        }
    }
}

void execute_program(Interpreter& interp, Program& program, std::vector<Diagnostic>* diags) {
    ExecState state{interp, {&interp.globals}, diags, false, Value()};
    for (Stmt* stmt : program.statements) {
        exec_stmt(state, stmt);
    }
    free_value(&state.return_value);  // a stray top-level `return` has nowhere to go; discard it
}

}  // namespace tinyscript
