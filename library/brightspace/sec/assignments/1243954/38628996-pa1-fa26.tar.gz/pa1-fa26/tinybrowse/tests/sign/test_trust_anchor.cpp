#include "tinytest.h"

#include <fstream>
#include <sstream>
#include <string>

#include "mbedtls/x509_crt.h"
#include "sign/trust_anchor.h"

namespace {

bool read_file(const std::string& path, std::string* out) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        return false;
    }
    std::ostringstream buffer;
    buffer << file.rdbuf();
    *out = buffer.str();
    return true;
}

std::string pki_fixture(const char* name) {
    return std::string(TINYBROWSE_SIGN_FIXTURES_DIR) + "/pki/" + name;
}

}  // namespace

TEST_CASE(trust_anchor_parses_and_is_self_signed) {
    mbedtls_x509_crt root;
    mbedtls_x509_crt_init(&root);
    CHECK_EQ(sign::load_trust_anchor(&root), 0);

    char subject[256];
    char issuer[256];
    CHECK(mbedtls_x509_dn_gets(subject, sizeof(subject), &root.subject) > 0);
    CHECK(mbedtls_x509_dn_gets(issuer, sizeof(issuer), &root.issuer) > 0);
    CHECK_EQ(std::string(subject), std::string("CN=tinybrowse-pinned-root"));
    CHECK_EQ(std::string(subject), std::string(issuer));

    mbedtls_x509_crt_free(&root);
}

TEST_CASE(fixture_leaf_cert_chains_to_the_trust_anchor) {
    mbedtls_x509_crt root;
    mbedtls_x509_crt_init(&root);
    CHECK_EQ(sign::load_trust_anchor(&root), 0);

    std::string leaf_der;
    CHECK(read_file(pki_fixture("leaf_cert.der"), &leaf_der));
    mbedtls_x509_crt leaf;
    mbedtls_x509_crt_init(&leaf);
    CHECK_EQ(mbedtls_x509_crt_parse_der(
                 &leaf, reinterpret_cast<const unsigned char*>(leaf_der.data()), leaf_der.size()),
             0);

    uint32_t flags = 0;
    int ret = mbedtls_x509_crt_verify(&leaf, &root, nullptr, nullptr, &flags, nullptr, nullptr);
    CHECK_EQ(ret, 0);
    CHECK_EQ(flags, static_cast<uint32_t>(0));

    mbedtls_x509_crt_free(&leaf);
    mbedtls_x509_crt_free(&root);
}

TEST_CASE(a_cert_not_signed_by_the_trust_anchor_fails_verification) {
    mbedtls_x509_crt root;
    mbedtls_x509_crt_init(&root);
    CHECK_EQ(sign::load_trust_anchor(&root), 0);

    // Reuses phase 0's unrelated throwaway self-signed cert -- it has no
    // relationship to tinybrowse's pinned root, so verification must fail.
    std::string unrelated_der;
    CHECK(read_file(std::string(TINYBROWSE_SIGN_FIXTURES_DIR) + "/smoke_cert.der", &unrelated_der));
    mbedtls_x509_crt unrelated;
    mbedtls_x509_crt_init(&unrelated);
    CHECK_EQ(mbedtls_x509_crt_parse_der(&unrelated,
                                         reinterpret_cast<const unsigned char*>(unrelated_der.data()),
                                         unrelated_der.size()),
             0);

    uint32_t flags = 0;
    int ret = mbedtls_x509_crt_verify(&unrelated, &root, nullptr, nullptr, &flags, nullptr, nullptr);
    CHECK(ret != 0);
    CHECK(flags != 0);

    mbedtls_x509_crt_free(&unrelated);
    mbedtls_x509_crt_free(&root);
}

TINYTEST_MAIN()
