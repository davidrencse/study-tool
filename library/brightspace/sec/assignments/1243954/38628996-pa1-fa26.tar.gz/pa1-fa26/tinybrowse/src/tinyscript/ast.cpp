#include "tinyscript/ast.h"

namespace tinyscript {

void free_expr(Expr* expr) {
    if (expr == nullptr) {
        return;
    }
    free_expr(expr->left);
    free_expr(expr->right);
    for (Expr* arg : expr->args) {
        free_expr(arg);
    }
    free_expr(expr->cast_operand);
    for (Expr* e : expr->array_elements) {
        free_expr(e);
    }
    free_expr(expr->index_array);
    free_expr(expr->index_expr);
    delete expr;
}

void free_stmt(Stmt* stmt) {
    if (stmt == nullptr) {
        return;
    }
    free_expr(stmt->var_init);
    free_type(stmt->var_type_annotation);
    free_expr(stmt->assign_index_target);
    for (Stmt* s : stmt->body) {
        free_stmt(s);
    }
    for (Stmt* s : stmt->else_body) {
        free_stmt(s);
    }
    for (Type* t : stmt->param_type_annotations) {
        free_type(t);
    }
    free_type(stmt->return_type_annotation);
    free_expr(stmt->expr);
    delete stmt;
}

void free_program(Program& program) {
    for (Stmt* stmt : program.statements) {
        free_stmt(stmt);
    }
    program.statements.clear();
}

}  // namespace tinyscript
