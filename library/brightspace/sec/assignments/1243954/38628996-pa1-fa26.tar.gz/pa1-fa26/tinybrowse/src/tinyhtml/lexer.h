#pragma once

#include <string>
#include <vector>

#include "tinyhtml/token.h"

namespace tinyhtml {

// Tokenizes tinyhtml source text per docs/tinyhtml-spec.md section 1.
// Always terminates with a single TokenType::EndOfFile token, even on
// malformed input -- the lexer never throws and never loops forever
// (see the spec's "Robustness requirements").
std::vector<Token> lex(const std::string& source);

}  // namespace tinyhtml
