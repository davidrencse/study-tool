#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "browser/browser.h"
#include "browser/repl.h"

namespace {

void print_usage(const char* prog) {
    std::fprintf(stderr,
                  "usage: %s [--exit-after-load] <file.thtml>\n"
                  "       %s [--exit-after-load] --url <http://host[:port]/path>\n",
                  prog, prog);
}

}  // namespace

int main(int argc, char** argv) {
    bool exit_after_load = false;
    std::vector<std::string> rest;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--exit-after-load") == 0) {
            exit_after_load = true;
        } else {
            rest.push_back(argv[i]);
        }
    }

    if (rest.size() == 2 && rest[0] == "--url") {
        return exit_after_load ? browser::load_and_render_url(rest[1]) : browser::browse_url(rest[1]);
    }
    if (rest.size() == 1) {
        return exit_after_load ? browser::load_and_render(rest[0]) : browser::browse_file(rest[0]);
    }

    print_usage(argv[0]);
    return 2;
}
