/* Compiled INTO the wasm sandbox alongside mbedtls itself. This is
 * tinybrowse's own glue code, not a modification to mbedtls -- it exists
 * because tinybrowse's RLBox integration treats mbedtls_x509_crt and
 * mbedtls_pk_context as opaque (sandbox-allocated, never dereferenced
 * field-by-field from host code): RLBox's struct-reflection mechanism would
 * otherwise be needed to expose `leaf.pk`, and mbedtls_x509_crt's fields are
 * mostly other structs embedded by value (mbedtls_x509_name, mbedtls_x509_buf,
 * mbedtls_x509_sequence, ...), which is unsupported/untested territory in
 * the vendored RLBox. A single tiny accessor, running inside the sandbox
 * where the real struct layout is visible, sidesteps that entirely: the host
 * gets back an opaque tainted pointer to the `pk` field, never the field's
 * own contents.
 */
#include "mbedtls/pk.h"
#include "mbedtls/x509_crt.h"

mbedtls_pk_context *tinybrowse_get_pk(mbedtls_x509_crt *crt) {
    return &crt->pk;
}
