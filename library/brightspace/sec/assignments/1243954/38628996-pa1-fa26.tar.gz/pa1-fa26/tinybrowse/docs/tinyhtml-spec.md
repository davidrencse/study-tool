# tinyhtml specification

tinyhtml is a small, strict markup language. It looks like HTML but drops
the parts of real HTML parsing that exist for legacy-web-compatibility
(implied tags, quirks mode, unclosed-tag recovery heuristics, etc.). A
tinyhtml document either parses according to the grammar below, or the
parser reports a diagnostic — there is no "best effort" tag-soup recovery.

## 1. Lexical grammar

The lexer turns source text into a token stream. tinyhtml has exactly two
lexer modes: **data mode** (reading text/markup) and **tag mode** (reading
inside `< ... >`). The lexer switches to tag mode on `<` and back to data
mode after the matching `>`, except inside `<script>`, which is special
(see §5).

```
token       ::= TAG_OPEN | TAG_CLOSE | TAG_END | TAG_SELF_CLOSE
              | IDENT | STRING | EQUALS | TEXT | EOF

TAG_OPEN    ::= "<" IDENT          ; e.g. start of "<p"
TAG_CLOSE   ::= "</" IDENT ">"     ; e.g. "</p>"
TAG_END     ::= ">"
TAG_SELF_CLOSE ::= "/>"
EQUALS      ::= "="
IDENT       ::= [a-zA-Z][a-zA-Z0-9-]*
STRING      ::= '"' (any char except '"')* '"'
TEXT        ::= (any char except '<')+
```

Whitespace inside tag mode (between attributes) is insignificant and
skipped by the lexer. Whitespace inside `TEXT` is significant and passed
through to the DOM as-is (the renderer, not the parser, is responsible for
any collapsing).

### Character references (entities)

Inside `TEXT` and attribute `STRING` values, exactly five entities are
recognized and decoded by the lexer: `&lt;` `&gt;` `&amp;` `&quot;`
`&apos;`. An `&` not followed by one of these five names (case-sensitive,
including the trailing `;`) is a literal `&` — it is **not** an error.
Unrecognized `&...;` sequences just pass through unchanged.

## 2. Context-free grammar

```
Document       ::= Node*

Node           ::= Element | Text

Element        ::= VoidElement | ContainerElement

VoidElement    ::= "<" "br" Attribute* ( "/>" | ">" )

ContainerElement
               ::= "<" TagName Attribute* ">" Node* "</" TagName ">"

TagName        ::= "h1" | "h2" | "h3" | "p" | "b" | "i" | "u"
                  | "a" | "div" | "span" | "ul" | "ol" | "li"
                  | "script" | "title"

Attribute      ::= IDENT "=" STRING

Text           ::= TEXT
```

Constraints not expressible in the CFG above, enforced by the parser:

1. **Tag name matching.** The `TagName` in a `ContainerElement`'s closing
   tag must exactly match its opening tag (case-sensitive). Mismatch is a
   parse error (no implied auto-closing).
2. **`<script>` is a container element** but its content is *not* parsed
   as `Node*` — see §5.
3. **Attribute name uniqueness.** An attribute name repeated on the same
   tag is a parse error.
4. **Known attributes per tag** (the parser does not reject unknown
   attribute *names* — that's a semantic/DOM concern an interpreter or
   linter can layer on top — but the reference implementation's DOM only
   defines behavior for):

   | Attribute | Valid on | Meaning |
   |---|---|---|
   | `id` | any element | unique element identifier, used by `getElementById` |
   | `class` | any element | space-separated class list (styling hook) |
   | `href` | `a` | link target (a path/URL string; tinybrowse defines what it resolves to) |
   | `onclick` | any element | name of a tinyscript function to invoke on activation |
   | `onload` | any element | name of a tinyscript function to invoke once, after the document finishes loading and running top-level scripts |
   | `type` | `script` | `"tinyscript"` (default) or `"typyscript"` — selects which language the element's content is parsed as. All `<script>` elements in one document must agree: the document's dialect is fixed by the first `<script>` tag encountered, and a later tag with a disagreeing `type` is treated as a script-execution failure, not a tinyhtml parse error (see `typyscript-spec.md`). |

## 3. Document structure

Unlike HTML5, tinyhtml has **no implied `<html>`/`<head>`/`<body>`.** A
document is simply a flat sequence of nodes. `<title>` may appear anywhere
at the top level and sets the browser's window/tab title (only the first
one found is used; a second is a parser warning, not an error).

## 4. The DOM tree

The parser's output is a tree of `Node` values (see `../STYLE.md` for the
ownership rules — this tree is raw-pointer-owned, not `shared_ptr`-owned):

```cpp
enum class NodeType { Document, Element, Text };

struct Attribute {
    std::string name;
    std::string value;
    Attribute* next;     // singly-linked list of this element's attributes
};

struct Node {
    NodeType type;

    // valid when type == Element
    std::string tag_name;
    Attribute* attributes = nullptr;

    // valid when type == Text
    std::string text;

    // tree links, valid for all node types except the root Document node's
    // parent, which is nullptr
    Node* parent = nullptr;
    Node* first_child = nullptr;
    Node* next_sibling = nullptr;
};
```

`Document` is always the single root `Node`; its children are the
top-level `Node*`s from the grammar's `Document ::= Node*` production.

## 5. `<script>` handling

`<script>` content is read by the lexer as **raw text up to the literal
byte sequence `</script>`** — it is not tokenized as tinyhtml markup, and
entity decoding does *not* apply inside it. This mirrors how real HTML
treats `<script>`/`<style>` as "raw text elements," and it means a
tinyscript program can freely contain `<`, `&`, or `"` without escaping.

The parser stores the raw text as the *single* `Text` child of the
`<script>` element. It is `tinyscript`'s (or `typyscript`'s) job — not
tinyhtml's — to lex and parse that text as a program; see
`tinyscript-spec.md` / `typyscript-spec.md`.

Because the raw-text scan looks for a literal `</script>`, a script whose
source text contains that exact substring (for example inside a string
literal) will have its content truncated at that point rather than parsed
as intended.

## 6. Robustness requirements

The parser must satisfy the following properties on any input, well-formed
or not:

- **No unbounded recursion driven directly by input nesting depth.** A
  document consisting of one million nested `<div>` tags must not crash
  the parser via native call-stack overflow. The reference implementation
  enforces a configurable maximum nesting depth (default 512) and reports
  a diagnostic instead of recursing past it.
- **Linear-time, single-pass lexing.** No lexer rule requires unbounded
  lookahead or backtracking over previously-consumed input.
- **No unbounded memory blowup from a small input.** There is no entity
  system that can expand (unlike XML's billion-laughs attack — see §1).
- On any parse error, the parser returns a diagnostic and a partial
  (possibly empty) tree — it never crashes and never loops forever.

## 7. Example

```html
<title>Example</title>
<h1 id="banner">Welcome</h1>
<p>This is <b>tinyhtml</b>, a small markup language.</p>
<ul>
  <li><a href="/about" onclick="showAbout">About</a></li>
  <li>Second item</li>
</ul>
<script>
let banner = getElementById("banner");
if (is_ok(banner)) {
    setText(unwrap(banner), "Welcome!");
}
</script>
```
