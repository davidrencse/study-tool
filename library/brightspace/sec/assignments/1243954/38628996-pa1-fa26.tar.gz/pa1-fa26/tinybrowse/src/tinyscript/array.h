#pragma once

#include <cstddef>
#include <cstdint>
#include <vector>

#include "tinyscript/diagnostic.h"
#include "tinyscript/value.h"

namespace tinyscript {

// See docs/tinyscript-spec.md section 5 (Arrays).

// Allocates a fixed-length array of `length` slots, each initially Unit
// (never raw uninitialized memory -- see docs/instructor/
// tinyscript-design-notes.md for why). Arrays never grow or shrink.
Value array_new(size_t length);

size_t array_len(const Value& arr);

// Bounds-checked reference into `arr`'s buffer, for the interpreter's
// internal use resolving assignment targets (`interpreter.cpp`). Returns
// nullptr (with a Diagnostic recorded at `line`) if `index` is out of
// range. Prefer array_get/array_set for straightforward reads/writes --
// this exists so chained index-assignment (`matrix[i][j] = x`) can
// correctly mutate the real, nested array rather than a copy of it.
Value* array_ref(Value& arr, int64_t index, int line, std::vector<Diagnostic>* diags);

// Bounds-checked read: returns a deep copy of the element at `index` (a
// copy because Value has no copy constructor -- see value.h -- and because
// this is how any other expression produces an independent Value to use).
// An out-of-range index (negative, or >= array_len(arr)) records a
// Diagnostic at `line` and returns Unit instead of touching memory outside
// the array's buffer.
Value array_get(const Value& arr, int64_t index, int line, std::vector<Diagnostic>* diags);

// Bounds-checked write. In bounds, the slot's previous contents are
// released before `val` is written (via Value's move-assignment -- see
// value.cpp). Out of range, `val` can't be stored, so it's freed instead
// (otherwise whatever it owned would leak) and a Diagnostic is recorded at
// `line`; the array itself is left unchanged.
void array_set(Value& arr, int64_t index, Value val, int line, std::vector<Diagnostic>* diags);

// Returns a newly allocated array holding `a`'s elements followed by `b`'s
// (each deep-copied). Neither `a` nor `b` is modified.
Value array_concat(const Value& a, const Value& b);

// Removes and returns `arr`'s last element as Ok(value), reducing its
// length by one. Err(()) (with a Diagnostic at `line`) if `arr` is empty.
Value array_pop(Value& arr, int line, std::vector<Diagnostic>* diags);

}  // namespace tinyscript
