#include "tinytest.h"

#include <cstdint>
#include <limits>

#include "tinyscript/numeric.h"

using namespace tinyscript;

TEST_CASE(promote_kind_same_kind_is_identity) {
    CHECK(promote_kind(NumKind::U8, NumKind::U8) == NumKind::U8);
    CHECK(promote_kind(NumKind::F64, NumKind::F64) == NumKind::F64);
}

TEST_CASE(promote_kind_wider_int_wins_on_different_width) {
    CHECK(promote_kind(NumKind::U8, NumKind::U32) == NumKind::U32);
    CHECK(promote_kind(NumKind::U8, NumKind::I64) == NumKind::I64);
    CHECK(promote_kind(NumKind::I8, NumKind::I32) == NumKind::I32);
}

TEST_CASE(promote_kind_same_width_unsigned_wins_the_cwe190_footgun) {
    // The deliberate footgun documented in docs/instructor/
    // tinyscript-design-notes.md: same-width, different-signedness
    // promotes to unsigned, silently reinterpreting a negative operand.
    CHECK(promote_kind(NumKind::I32, NumKind::U32) == NumKind::U32);
    CHECK(promote_kind(NumKind::U32, NumKind::I32) == NumKind::U32);
    CHECK(promote_kind(NumKind::I64, NumKind::U64) == NumKind::U64);
    CHECK(promote_kind(NumKind::I8, NumKind::U8) == NumKind::U8);
}

TEST_CASE(promote_kind_float_always_beats_int) {
    CHECK(promote_kind(NumKind::I64, NumKind::F32) == NumKind::F32);
    CHECK(promote_kind(NumKind::U8, NumKind::F64) == NumKind::F64);
    CHECK(promote_kind(NumKind::F32, NumKind::F64) == NumKind::F64);
}

TEST_CASE(promote_kind_is_symmetric_for_every_pair) {
    NumKind kinds[8] = {NumKind::U8,  NumKind::U32, NumKind::U64, NumKind::I8,
                        NumKind::I32, NumKind::I64, NumKind::F32, NumKind::F64};
    for (NumKind a : kinds) {
        for (NumKind b : kinds) {
            CHECK(promote_kind(a, b) == promote_kind(b, a));
        }
    }
}

TEST_CASE(wraparound_arithmetic_matches_spec_examples) {
    CHECK_EQ(wrap_add_u8(254, 5), static_cast<uint8_t>(3));
    CHECK_EQ(wrap_add_i8(127, 1), static_cast<int8_t>(-128));
    CHECK_EQ(wrap_add_i32(std::numeric_limits<int32_t>::max(), 1),
              std::numeric_limits<int32_t>::min());
    CHECK_EQ(wrap_sub_u32(0, 1), std::numeric_limits<uint32_t>::max());
    CHECK_EQ(wrap_mul_u8(200, 2), static_cast<uint8_t>(144));
}

TEST_CASE(wraparound_arithmetic_agrees_with_plain_math_when_no_overflow) {
    CHECK_EQ(wrap_add_u32(2, 3), static_cast<uint32_t>(5));
    CHECK_EQ(wrap_sub_i32(10, 3), 7);
    CHECK_EQ(wrap_mul_i64(6, 7), static_cast<int64_t>(42));
}

TEST_CASE(integer_division_by_zero_is_a_diagnostic_not_a_crash) {
    std::vector<Diagnostic> diags;
    CHECK_EQ(wrap_div_i32(10, 0, 1, &diags), 0);
    CHECK_EQ(diags.size(), static_cast<size_t>(1));

    diags.clear();
    CHECK_EQ(wrap_mod_u8(10, 0, 1, &diags), static_cast<uint8_t>(0));
    CHECK_EQ(diags.size(), static_cast<size_t>(1));
}

TEST_CASE(division_by_nonzero_produces_no_diagnostic) {
    std::vector<Diagnostic> diags;
    CHECK_EQ(wrap_div_i32(10, 3, 1, &diags), 3);
    CHECK(diags.empty());
}

TEST_CASE(most_negative_divided_by_negative_one_wraps_instead_of_overflowing) {
    std::vector<Diagnostic> diags;
    CHECK_EQ(wrap_div_i32(std::numeric_limits<int32_t>::min(), -1, 1, &diags),
              std::numeric_limits<int32_t>::min());
    CHECK(diags.empty());  // not a divide-by-zero; the other overflow case

    CHECK_EQ(wrap_mod_i32(std::numeric_limits<int32_t>::min(), -1, 1, &diags), 0);
}

TINYTEST_MAIN()
