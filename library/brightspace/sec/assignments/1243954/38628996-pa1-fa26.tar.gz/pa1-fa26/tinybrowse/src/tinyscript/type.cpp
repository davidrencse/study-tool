#include "tinyscript/type.h"

namespace tinyscript {

Type::Type(Type&& other) noexcept
    : kind(other.kind),
      result_ok_type(other.result_ok_type),
      result_err_type(other.result_err_type),
      array_element_type(other.array_element_type) {
    other.result_ok_type = nullptr;
    other.result_err_type = nullptr;
    other.array_element_type = nullptr;
}

Type& Type::operator=(Type&& other) noexcept {
    if (this == &other) {
        return *this;
    }
    free_type(result_ok_type);
    free_type(result_err_type);
    free_type(array_element_type);
    kind = other.kind;
    result_ok_type = other.result_ok_type;
    result_err_type = other.result_err_type;
    array_element_type = other.array_element_type;
    other.result_ok_type = nullptr;
    other.result_err_type = nullptr;
    other.array_element_type = nullptr;
    return *this;
}

Type* make_type(TypeKind kind) {
    Type* t = new Type();
    t->kind = kind;
    return t;
}

void free_type(Type* t) {
    if (t == nullptr) {
        return;
    }
    free_type(t->result_ok_type);
    free_type(t->result_err_type);
    free_type(t->array_element_type);
    delete t;
}

Type copy_type(const Type& t) {
    Type out;
    out.kind = t.kind;
    if (t.result_ok_type != nullptr) {
        out.result_ok_type = new Type(copy_type(*t.result_ok_type));
    }
    if (t.result_err_type != nullptr) {
        out.result_err_type = new Type(copy_type(*t.result_err_type));
    }
    if (t.array_element_type != nullptr) {
        out.array_element_type = new Type(copy_type(*t.array_element_type));
    }
    return out;
}

void release_type(Type& t) {
    free_type(t.result_ok_type);
    free_type(t.result_err_type);
    free_type(t.array_element_type);
    t.result_ok_type = nullptr;
    t.result_err_type = nullptr;
    t.array_element_type = nullptr;
}

}  // namespace tinyscript
