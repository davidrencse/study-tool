#pragma once

#include <string>
#include <vector>

#include "tinyscript/token.h"

namespace tinyscript {

// Tokenizes tinyscript/typyscript source text per docs/
// tinyscript-spec.md section 1 (both dialects share one lexer/grammar --
// see docs/typyscript-spec.md). Always terminates with a single
// TokenType::EndOfFile token; never throws, never loops forever on
// malformed input.
std::vector<Token> lex(const std::string& source);

}  // namespace tinyscript
