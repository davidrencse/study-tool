# Assignment 1: Intro to tinybrowse and tools *(16 pts)*

**Deadline: 9/15**

This assignment has two goals. First, to get you comfortable with the tools you'll rely on for the rest of the course: `grep` (code search), `gdb` (debugger), and `strace` (system call tracer).
Second, to get you familiar with tinybrowse, the web browser that you will be attacking and defending for the rest of the semester. 

## What is tinybrowse?

**tinybrowse** is a tiny web browser. 
Tinybrowse works like any other web browser: it takes a text file describing the page (the text, links, scripts, etc) and turns it into something you can look at and interact with. 
Tinybrowse does this by reading a `.thtml` (tinyhtml) file,
executing any tinyscript (like javascript) or typyscript (like typescript) scripts within the file, and printing out the finished result. 

## Part 0: Getting Started

### Part 0.1: Setting up your environment

This course provides a VM with all the tools you need for the assignments.
Assignments are *not* included in the VM; you copy those in yourself (see below).

You will need QEMU to run the VM, so install it if you don't have it already.

#### 1. Unpack the image

Verify the download first if you like:
```sh
sha256sum -c SHA256SUMS
```

```sh
xz -d cs3923-fa26.qcow2.xz
```

#### 2. Boot it

On **macOS / Linux**, downloading strips the executable bit, so restore it once:

```sh
chmod +x run-vm.sh
./run-vm.sh
```

The VM is headless and designed to run in the background, so don't be surprised if you don't see anything happen. Wait ~20 seconds, then:

```sh
ssh -p 2222 student@localhost
```

Login is `student` / `tinybrowse`.

Shut it down with `./run-vm.sh --stop`.

Want more resources? `MEM=4096 CPUS=4 ./run-vm.sh`.

#### 3. Get the assignment into the VM

From your **host** machine, in the directory holding the tarball:

```sh
scp -P 2222 pa1-fa26.tar.gz student@localhost:~
```

You should then see it inside your VM.

### Part 0.2: Building tinybrowse

Now, inside the VM, let's start by building tinybrowse:

```sh
cd tinybrowse
make build
```
The resulting binary should be at `build/src/browser/tinybrowse`.
It takes the path to a `.thtml` file to load and render. 
By default it renders the page and then drops into an interactive prompt; pass `--exit-after-load` to render and exit instead.
**Use `--exit-after-load` for every exercise in this assignment** -- without it you land in the REPL, which may change your results.


Let's try to actually render a page in tinybrowse:
```sh 
build/src/browser/tinybrowse --exit-after-load examples/hello.thtml
```

You should see a simple web page rendered in your terminal!
```
Hello, tinybrowse!

This is the simplest possible tinyhtml document: a title, a heading, and a
paragraph of text.
```

Next, to check that tinybrowse is fully functional, run:
```sh
make test
```
You should see that tinybrowse ran its test suite with 0 failures.


Skim `docs/` and `examples/` before you start: you will find lots of useful information pertaining to this assignment (and future assignments). 

You're going to spend the rest of this course reading, running, and breaking tinybrowse, so its important get comfortable with the tools that make this easier.
Each part of this assignment introduces you to a useful tool and has you use it to do some preliminary threat modeling on tinybrowse. 

## Part 1: Using `grep` *(4 pts)*

Throughout your life, you're going to spend a lot of time reading code you didn't write, and grep helps you do it efficiently. 
For example, `grep -rn` is the fastest way to answer "where is this defined?," "what function calls this?" and "how many places would I need to change to implement a new feature?." 

A few flags worth knowing:
- `-r` — recurse into a directory
- `-n` — show line numbers
- `-i` — case-insensitive

### Exercises

Note: run these commands on the `src/` directory, i.e., ignore `third_party/`.

1. Run `grep -rn "array_new" src/`. Which single `file:line` is the real
   definition? *(1 pt)*
2. tinyscript registers its builtins (functions callable from scripts) two different ways: a static table (`core_builtins()`) and individual `register_builtin(...)` calls. Using grep, find every builtin name a
   tinyscript/typyscript `<script>` block can call. *(2 pts)*
3. Tinybrowse's C++ objects are manually allocated and deallocated with 
   `new`/`delete` (no smart pointers, if you know what those are). Use grep to find every file that performs raw allocation/deallocation. 
   Based on what each of these files does, did you expect all of them to be managing memory directly like this? Which ones surprised you, if any? *(1 pt)*

## Part 2: Using GDB *(7 pts)*

Reading source code tells you what a program is supposed to do, but gdb lets you pause it mid-execution and see what it's actually doing.

Some useful commands:

1. **Starting.** Launch with `gdb build/src/browser/tinybrowse`, then set some breakpoints you can use for analysis:
   - `b browser::load_and_render` — break at a function by name
   - `run --exit-after-load examples/tinyscript-demo.thtml` — run with arguments
2. **Analyzing.**
   - `info args` — show the current function's arguments
   - `disas browser::load_and_render` — show the assembly code
   - `bt` (or `where`) — show the call stack
   - `p <expr>` — print a variable or expression, e.g. `p args[0]`
   - `finish` — run until the current function returns
   - `x $eip` — examine current instruction pointer
3. **Continuing.**
   - `c` — continue until the next breakpoint
   - `s` / `si` — step one line / one instruction

Note that this is only a cursory overview of GDB; much more info is available from online resources.

### Exercises

1. Set breakpoints on `browser::load_and_render`, `tinyhtml::parse`, and `builtin_print`, then run on `examples/tinyscript-demo.thtml`
  At the `load_and_render` breakpoint: what is the value of `path`, and (using `bt`) what is the *only* other frame on the stack. *(2 pts)*
2. `continue` to the `tinyhtml::parse` breakpoint and run `bt` to see the whole call stack. How many frames are there? Does the module each frame belongs to (its directory under `src/`) match what you'd expect from tinybrowse's load pipeline? *(2 pts)*
3. Start a fresh session and run on `examples/typyscript-demo.thtml` with a breakpoint on `call_user_function`. 
   Continue until it triggers on the document's `total(scores)` call (a user function). Run `info proc mappings` and note the ranges labeled `[heap]` and `[stack]`, then `p &args[0]` and `p &state`. Which memory regions do each of these live in, and why does it make sense that `args[0]`'s storage and `state`'s storage live in different places? *(3 pts)*

## Part 3: Using `strace` *(5 pts)*

`strace` shows you every syscall a process makes, which tells you useful facts like "what files does this program open" or "how does this program talk to the network". This makes it a great tool for quickly identifying the attack surface of a program.

### Exploring without filters

Before narrowing in on anything specific, look at everything a run of tinybrowse actually does:

Start by running tinybrowse under strace:
```sh
strace ./build/src/browser/tinybrowse --exit-after-load examples/hello.thtml
```

1. Skim the trace of loading `hello.thtml` -- a five-line document. 
   Roughly how many syscalls does it use? How many of those are tinybrowse doing its own work (reading the file, writing the rendered output), as opposed to the OS setting up the process before tinybrowse's own code ever runs (loading shared libraries, allocating memory, etc.)? *(2 pts)*


Now that you've seen all the syscalls tinybrowse makes, let's use a filter to specifically analyze how tinybrowse loads files:

```sh
strace -e trace=openat,write ./build/src/browser/tinybrowse --exit-after-load examples/tinyscript-demo.thtml
```

2. Run the above command on `examples/tinyscript-demo.thtml`. 
   How many `write()` calls do you see, which file descriptors do they target? What are the roles of fd 1 and fd 2 here?  *(2 pts)*
3. Look at `read_file()` in `src/browser/browser.cpp` - it opens whatever
   `path` `load_and_render()` was given. Currently, that path only ever comes from `argv[1]`. Imagine a future version where a clicked link's `href` flowed into this same `path` argument. Give one
   concrete attacker-supplied path string that could lead to a security vulnerability *(1 pt)*

## Submission

Fill out [`assignment1-answers.txt`](assignment1-answers.txt) with your answers, following the directions in the template -- do not delete the square brackets. Submit it to Gradescope.
